package INTERFACES;
import CODES.DBconnect;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class training extends javax.swing.JPanel {
    Connection conn;
    PreparedStatement pst=null;
    ResultSet rs = null;
    public training() {
        initComponents();
        conn = DBconnect.connect();
        printtxt.hide();
    }
        String regno;
        String cource;
        String du1;
        String du2;
        String mod1;
        String mod2;
        String mod3;
        String mod4;
        String mod5;
        String mod6;
        String mod7;
        String mod8;
        String mod9;
        String mod10;
        String mod11;
        String mod12;
        String mod1l;
        String mod1a;
        String mod1c;
        String mod2l;
        String mod2a;
        String mod2c;
        String mod3l;
        String mod3a;
        String mod3c;      
        String mod4l;
        String mod4a;
        String mod4c;      
        String mod5l;
        String mod5a;
        String mod5c;     
        String mod6l;
        String mod6a;
        String mod6c;       
        String mod7l;
        String mod7a;
        String mod7c;      
        String mod8l;
        String mod8a;
        String mod8c;       
        String mod9l;
        String mod9a;
        String mod9c;        
        String mod10l;
        String mod10a;
        String mod10c;    
        String mod11l;
        String mod11a;
        String mod11c;  
        String mod12l;
        String mod12a;
        String mod12c;
        String level;     
//------------------------------------------------------------------------------------------------- 
private void savedata(){
regno=regnotxt.getText();
cource=courcetxt.getText();
SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
du1 = dateformat.format(du1txt.getDate());
du2 = dateformat.format(du2txt.getDate());
mod1=mod1txt.getText();
mod2=mod2txt.getText();
mod3=mod3txt.getText();
mod4=mod4txt.getText();
mod5=mod5txt.getText();
mod6=mod6txt.getText();
mod7=mod7txt.getText();
mod8=mod8txt.getText();
mod9=mod9txt.getText();
mod10=mod10txt.getText();
mod11=mod11txt.getText();
mod12=mod12txt.getText();
mod1l=mod1ltxt.getText();
mod1a=mod1atxt.getText();
mod1c=mod1ctxt.getText(); 
mod2l=mod2ltxt.getText();
mod2a=mod2atxt.getText();
mod2c=mod2ctxt.getText();   
mod3l=mod3ltxt.getText();
mod3a=mod3atxt.getText();
mod3c=mod3ctxt.getText();    
mod4l=mod4ltxt.getText();
mod4a=mod4atxt.getText();
mod4c=mod4ctxt.getText();  
mod5l=mod5ltxt.getText();
mod5a=mod5atxt.getText();
mod5c=mod5ctxt.getText();
mod6l=mod6ltxt.getText();
mod6a=mod6atxt.getText();
mod6c=mod6ctxt.getText();     
mod7l=mod7ltxt.getText();
mod7a=mod7atxt.getText();
mod7c=mod7ctxt.getText();    
mod8l=mod8ltxt.getText();
mod8a=mod8atxt.getText();
mod8c=mod8ctxt.getText();  
mod9l=mod9ltxt.getText();
mod9a=mod9atxt.getText();
mod9c=mod9ctxt.getText();        
mod10l=mod10ltxt.getText();
mod10a=mod10atxt.getText();
mod10c=mod10ctxt.getText();  
mod11l=mod11ltxt.getText();
mod11a=mod11atxt.getText();
mod11c=mod11ctxt.getText();  
mod12l=mod12ltxt.getText();
mod12a=mod12atxt.getText();
mod12c=mod12ctxt.getText();
level=leveltxt.getText();
}
//-------------------------------------------------------------------------------------------------        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        searchboxtxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        idtxt = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        courcetxt = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        du2txt = new com.toedter.calendar.JDateChooser();
        printtxt = new javax.swing.JButton();
        updatebtn = new javax.swing.JButton();
        registertxt = new javax.swing.JButton();
        deletebtn = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        du1txt = new com.toedter.calendar.JDateChooser();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        mod1txt = new javax.swing.JTextField();
        mod2txt = new javax.swing.JTextField();
        mod3txt = new javax.swing.JTextField();
        mod4txt = new javax.swing.JTextField();
        mod5txt = new javax.swing.JTextField();
        mod6txt = new javax.swing.JTextField();
        mod7txt = new javax.swing.JTextField();
        mod8txt = new javax.swing.JTextField();
        mod12txt = new javax.swing.JTextField();
        mod11txt = new javax.swing.JTextField();
        mod10txt = new javax.swing.JTextField();
        mod9txt = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        mod1atxt = new javax.swing.JTextField();
        mod2atxt = new javax.swing.JTextField();
        mod3atxt = new javax.swing.JTextField();
        mod4atxt = new javax.swing.JTextField();
        mod5atxt = new javax.swing.JTextField();
        mod6atxt = new javax.swing.JTextField();
        mod7atxt = new javax.swing.JTextField();
        mod8atxt = new javax.swing.JTextField();
        mod12atxt = new javax.swing.JTextField();
        mod11atxt = new javax.swing.JTextField();
        mod10atxt = new javax.swing.JTextField();
        mod9atxt = new javax.swing.JTextField();
        jPanel20 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        mod1ltxt = new javax.swing.JTextField();
        mod2ltxt = new javax.swing.JTextField();
        mod3ltxt = new javax.swing.JTextField();
        mod4ltxt = new javax.swing.JTextField();
        mod5ltxt = new javax.swing.JTextField();
        mod6ltxt = new javax.swing.JTextField();
        mod7ltxt = new javax.swing.JTextField();
        mod8ltxt = new javax.swing.JTextField();
        mod12ltxt = new javax.swing.JTextField();
        mod11ltxt = new javax.swing.JTextField();
        mod10ltxt = new javax.swing.JTextField();
        mod9ltxt = new javax.swing.JTextField();
        jPanel30 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        mod1ctxt = new javax.swing.JTextField();
        mod2ctxt = new javax.swing.JTextField();
        mod3ctxt = new javax.swing.JTextField();
        mod4ctxt = new javax.swing.JTextField();
        mod5ctxt = new javax.swing.JTextField();
        mod6ctxt = new javax.swing.JTextField();
        mod7ctxt = new javax.swing.JTextField();
        mod8ctxt = new javax.swing.JTextField();
        mod12ctxt = new javax.swing.JTextField();
        mod11ctxt = new javax.swing.JTextField();
        mod10ctxt = new javax.swing.JTextField();
        mod9ctxt = new javax.swing.JTextField();
        regnotxt = new javax.swing.JTextField();
        cleartxt1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        resipttxt = new javax.swing.JTextArea();
        jPanel16 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        totalbtn = new javax.swing.JButton();
        avglbl = new javax.swing.JLabel();
        totallbl1 = new javax.swing.JLabel();
        leveltxt = new javax.swing.JTextField();
        viewbtn = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1094, 1181));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 153, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Training Form");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        searchboxtxt.setToolTipText("Enter Registration No");
        searchboxtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchboxtxtKeyReleased(evt);
            }
        });
        jPanel2.add(searchboxtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 10, 250, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/search-2-24.png"))); // NOI18N
        jLabel2.setText("Search -");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1120, 50));

        idtxt.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        idtxt.setText("ID");
        jPanel1.add(idtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, 30));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel9.setText("Registration Number");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, 30));

        courcetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                courcetxtKeyReleased(evt);
            }
        });
        jPanel1.add(courcetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 500, 30));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel13.setText("To");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 239, -1, 30));

        du2txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(du2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 140, 30));

        printtxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        printtxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/printer-24.png"))); // NOI18N
        printtxt.setText("PRINT");
        printtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printtxtActionPerformed(evt);
            }
        });
        jPanel1.add(printtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 570, 200, 40));

        updatebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        updatebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/available-updates-24.png"))); // NOI18N
        updatebtn.setText("UPDATE");
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        jPanel1.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 950, 280, 40));

        registertxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        registertxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/add-user-3-24.png"))); // NOI18N
        registertxt.setText("REGISTER");
        registertxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registertxtMouseClicked(evt);
            }
        });
        registertxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registertxtActionPerformed(evt);
            }
        });
        jPanel1.add(registertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 950, 280, 40));

        deletebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        deletebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/delete-24.png"))); // NOI18N
        deletebtn.setText("DELETE");
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        jPanel1.add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1000, 280, 40));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel28.setText("Cource Duration");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, -1, 30));

        du1txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(du1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, 140, 30));

        jPanel3.setBackground(new java.awt.Color(0, 153, 51));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel4.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel9.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel4.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel4.add(mod1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 200, 30));
        jPanel4.add(mod2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 200, 30));
        jPanel4.add(mod3txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 200, 30));
        jPanel4.add(mod4txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 200, 30));
        jPanel4.add(mod5txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 200, 30));
        jPanel4.add(mod6txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 200, 30));
        jPanel4.add(mod7txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 200, 30));
        jPanel4.add(mod8txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 200, 30));
        jPanel4.add(mod12txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 200, 30));
        jPanel4.add(mod11txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 200, 30));
        jPanel4.add(mod10txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 200, 30));
        jPanel4.add(mod9txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 200, 30));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 220, 500));

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setText("MODULE 01");
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel15.setText("MODULE 02");
        jPanel5.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel16.setText("MODULE 03");
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel17.setText("MODULE 04");
        jPanel5.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel18.setText("MODULE 09");
        jPanel5.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, -1, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel19.setText("MODULE 10");
        jPanel5.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, -1, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel21.setText("MODULE 12");
        jPanel5.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, -1, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel22.setText("MODULE 11");
        jPanel5.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, -1, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel23.setText("MODULE 08");
        jPanel5.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, -1, -1));

        jLabel39.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel39.setText("MODULE 07");
        jPanel5.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, -1, -1));

        jLabel40.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel40.setText("MODULE 06");
        jPanel5.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        jLabel41.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel41.setText("MODULE 05");
        jPanel5.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 150, 500));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("FINAL ASSIGNMENTS COMPLETION RECORDS");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 350, 30));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 630, 400, 540));

        jPanel15.setBackground(new java.awt.Color(0, 153, 51));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(0, 153, 51));
        jLabel33.setText("MODULE");
        jPanel21.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 80, 30));

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(0, 153, 51));
        jLabel34.setText("LESSON");
        jPanel21.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 100, 30));

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(0, 153, 51));
        jLabel35.setText("ASSIGNMENTS");
        jPanel21.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 0, 140, 30));

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 153, 51));
        jLabel36.setText("CERTIFY");
        jPanel21.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 0, 80, 30));

        jPanel15.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 550, 30));

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("TRAINING RECORDS");
        jPanel15.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 0, 200, 40));

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel24.setText("MODULE 01");
        jPanel7.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel42.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel42.setText("MODULE 02");
        jPanel7.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        jLabel43.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel43.setText("MODULE 03");
        jPanel7.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel44.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel44.setText("MODULE 04");
        jPanel7.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, -1));

        jLabel45.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel45.setText("MODULE 09");
        jPanel7.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));

        jLabel46.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel46.setText("MODULE 10");
        jPanel7.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, -1, -1));

        jLabel47.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel47.setText("MODULE 12");
        jPanel7.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, -1, -1));

        jLabel48.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel48.setText("MODULE 11");
        jPanel7.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));

        jLabel49.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel49.setText("MODULE 08");
        jPanel7.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, -1, -1));

        jLabel50.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel50.setText("MODULE 07");
        jPanel7.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, -1));

        jLabel51.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel51.setText("MODULE 06");
        jPanel7.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        jLabel52.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel52.setText("MODULE 05");
        jPanel7.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        jPanel15.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 130, 500));

        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel11.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel13.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel11.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel11.add(mod1atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 100, 30));
        jPanel11.add(mod2atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 100, 30));
        jPanel11.add(mod3atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 100, 30));
        jPanel11.add(mod4atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 100, 30));
        jPanel11.add(mod5atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 100, 30));
        jPanel11.add(mod6atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 100, 30));
        jPanel11.add(mod7atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 100, 30));
        jPanel11.add(mod8atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 100, 30));
        jPanel11.add(mod12atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 100, 30));
        jPanel11.add(mod11atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 100, 30));
        jPanel11.add(mod10atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 100, 30));
        jPanel11.add(mod9atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 100, 30));

        jPanel15.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, 130, 500));

        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel20.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel28.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel28.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel20.add(jPanel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel20.add(mod1ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 100, 30));
        jPanel20.add(mod2ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 100, 30));
        jPanel20.add(mod3ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 100, 30));
        jPanel20.add(mod4ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 100, 30));
        jPanel20.add(mod5ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 100, 30));
        jPanel20.add(mod6ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 100, 30));
        jPanel20.add(mod7ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 100, 30));
        jPanel20.add(mod8ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 100, 30));
        jPanel20.add(mod12ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 100, 30));
        jPanel20.add(mod11ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 100, 30));
        jPanel20.add(mod10ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 100, 30));
        jPanel20.add(mod9ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 100, 30));

        jPanel15.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 130, 500));

        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel31.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel30.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel33.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel32.add(jPanel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel30.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel30.add(mod1ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 100, 30));
        jPanel30.add(mod2ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 100, 30));
        jPanel30.add(mod3ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 100, 30));
        jPanel30.add(mod4ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 100, 30));
        jPanel30.add(mod5ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 100, 30));
        jPanel30.add(mod6ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 100, 30));
        jPanel30.add(mod7ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 100, 30));
        jPanel30.add(mod8ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 100, 30));
        jPanel30.add(mod12ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 100, 30));
        jPanel30.add(mod11ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 100, 30));
        jPanel30.add(mod10ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 100, 30));
        jPanel30.add(mod9ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 100, 30));

        jPanel15.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 80, 130, 500));

        jPanel1.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 570, 590));

        regnotxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                regnotxtKeyReleased(evt);
            }
        });
        jPanel1.add(regnotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 500, 30));

        cleartxt1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cleartxt1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/x-mark-4-24.png"))); // NOI18N
        cleartxt1.setText("CLEAR");
        cleartxt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cleartxt1ActionPerformed(evt);
            }
        });
        jPanel1.add(cleartxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 1000, 280, 40));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel8.setText("Cource");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, -1, 30));

        resipttxt.setColumns(20);
        resipttxt.setRows(5);
        jScrollPane1.setViewportView(resipttxt);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 70, 410, 490));

        jPanel16.setBackground(new java.awt.Color(0, 153, 51));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel53.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(255, 255, 255));
        jLabel53.setText("OVERALL TRAINING LEVEL");
        jPanel16.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 250, 30));

        totalbtn.setText("CALCULATE TOTAL AND AVERAGE");
        totalbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalbtnActionPerformed(evt);
            }
        });
        jPanel16.add(totalbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 610, 230, 40));

        avglbl.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        avglbl.setText("Average");
        jPanel16.add(avglbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 610, 80, 40));

        totallbl1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        totallbl1.setText("Total");
        jPanel16.add(totallbl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 610, 50, 40));

        leveltxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                leveltxtKeyReleased(evt);
            }
        });
        jPanel16.add(leveltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, 90, 30));

        jPanel1.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 890, 570, 50));

        viewbtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        viewbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/eye-2-32.png"))); // NOI18N
        viewbtn.setText("VIEW");
        viewbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewbtnActionPerformed(evt);
            }
        });
        jPanel1.add(viewbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 570, 200, 40));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 1180));
    }// </editor-fold>//GEN-END:initComponents

    private void searchboxtxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchboxtxtKeyReleased
        if (searchboxtxt.getText().isEmpty()) {
            clear();
        }
        else{searchbox();};
    }//GEN-LAST:event_searchboxtxtKeyReleased

    private void courcetxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_courcetxtKeyReleased

    }//GEN-LAST:event_courcetxtKeyReleased
//------------------------------------------------------------------------------------------------- 
    private void printtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printtxtActionPerformed
        
        try {
            resipttxt.print();
        } catch (PrinterException ex) {
            Logger.getLogger(register_page.class.getName()).log(Level.SEVERE, null, ex);    }
    }//GEN-LAST:event_printtxtActionPerformed
//------------------------------------------------------------------------------------------------- 
    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed

        savedata();
        update();
    }//GEN-LAST:event_updatebtnActionPerformed

    private void registertxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registertxtMouseClicked

    }//GEN-LAST:event_registertxtMouseClicked
//------------------------------------------------------------------------------------------------- 
    private void registertxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registertxtActionPerformed
        savedata();
        try {
            String sql = "INSERT INTO training (regno,cource,du1,du2,mod1,mod2,mod3,mod4,mod5,mod6,mod7,mod8,mod9,mod10,mod11,mod12,mod1l,mod1a,mod1c,mod2l,mod2a,mod2c,mod3l,mod3a,mod3c,mod4l,mod4a,mod4c,mod5l,mod5a,mod5c,mod6l,mod6a,mod6c,mod7l,mod7a,mod7c,mod8l,mod8a,mod8c,mod9l,mod9a,mod9c,mod10l,mod10a,mod10c,mod11l,mod11a,mod11c,mod12l,mod12a,mod12c,level)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            pst = conn.prepareStatement(sql);
            pst.setString(1,regno);
            pst.setString(2,cource);
            pst.setString(3,du1);
            pst.setString(4,du2);
            pst.setString(5,mod1);
            pst.setString(6,mod2);
            pst.setString(7,mod3);
            pst.setString(8,mod4);
            pst.setString(9,mod5);
            pst.setString(10,mod6);
            pst.setString(11,mod7);
            pst.setString(12,mod8);
            pst.setString(13,mod9);
            pst.setString(14,mod10);
            pst.setString(15,mod11);
            pst.setString(16,mod12);
            pst.setString(17,mod1l);
            pst.setString(18,mod1a);
            pst.setString(19,mod1c);
            pst.setString(20,mod2l);
            pst.setString(21,mod2a);
            pst.setString(22,mod2c);
            pst.setString(23,mod3l);
            pst.setString(24,mod3a);
            pst.setString(25,mod3c);
            pst.setString(26,mod4l);
            pst.setString(27,mod4a);
            pst.setString(28,mod4c);
            pst.setString(29,mod5l);
            pst.setString(30,mod5a);
            pst.setString(31,mod5c);
            pst.setString(32,mod6l);
            pst.setString(33,mod6a);
            pst.setString(34,mod6c);
            pst.setString(35,mod7l);
            pst.setString(36,mod7a);
            pst.setString(37,mod7c);
            pst.setString(38,mod8l);
            pst.setString(39,mod8a);
            pst.setString(40,mod8c);
            pst.setString(41,mod9l);
            pst.setString(42,mod9a);
            pst.setString(43,mod9c);
            pst.setString(44,mod10l);
            pst.setString(45,mod10a);
            pst.setString(46,mod10c);
            pst.setString(47,mod11l);
            pst.setString(48,mod11a);
            pst.setString(49,mod11c);
            pst.setString(50,mod12l);
            pst.setString(51,mod12a);
            pst.setString(52,mod12c);
            pst.setString(53,level);
            pst.execute();
            JOptionPane.showMessageDialog(null,"Data Insert Success!!!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"error");
        }
    }//GEN-LAST:event_registertxtActionPerformed
//-------------------------------------------------------------------------------------------------              
public void autocomplete(){       
        String search = regnotxt.getText();     
        try {
            String sql = "SELECT cource,du1,du2 FROM payments WHERE regno LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
            courcetxt.setText(rs.getString("cource"));
            du1txt.setDate(rs.getDate("du1"));
            du2txt.setDate(rs.getDate("du2"));
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     } }
    
//------------------------------------------------------------------------------------------------- 
    public void clear(){
regnotxt.setText("");
courcetxt.setText("");
du1txt.setDate(null);
du2txt.setDate(null);
mod1txt.setText("");
mod2txt.setText("");
mod3txt.setText("");
mod4txt.setText("");
mod5txt.setText("");
mod6txt.setText("");
mod7txt.setText("");
mod8txt.setText("");
mod9txt.setText("");
mod10txt.setText("");
mod11txt.setText("");
mod12txt.setText("");
mod1ltxt.setText("");
mod1atxt.setText("");
mod1ctxt.setText("");      
mod2ltxt.setText("");
mod2atxt.setText("");
mod2ctxt.setText("");      
mod3ltxt.setText("");
mod3atxt.setText("");
mod3ctxt.setText("");  
mod4ltxt.setText("");
mod4atxt.setText("");
mod4ctxt.setText("");  
mod5ltxt.setText("");
mod5atxt.setText("");
mod5ctxt.setText("");    
mod6ltxt.setText("");
mod6atxt.setText("");
mod6ctxt.setText("");     
mod7ltxt.setText("");
mod7atxt.setText("");
mod7ctxt.setText("");      
mod8ltxt.setText("");
mod8atxt.setText("");
mod8ctxt.setText("");      
mod9ltxt.setText("");
mod9atxt.setText("");
mod9ctxt.setText("");       
mod10ltxt.setText("");
mod10atxt.setText("");
mod10ctxt.setText("");   
mod11ltxt.setText("");
mod11atxt.setText("");
mod11ctxt.setText("");   
mod12ltxt.setText("");
mod12atxt.setText("");
mod12ctxt.setText("");
leveltxt.setText("");
resipttxt.setText("");
idtxt.setText("");
}
//------------------------------------------------------------------------------------------------- 
public void searchbox(){       
        String search = searchboxtxt.getText();     
        try {
            String sql = "SELECT regno,cource,du1,du2,mod1,mod2,mod3,mod4,mod5,mod6,mod7,mod8,mod9,mod10,mod11,mod12,mod1l,mod1a,mod1c,mod2l,mod2a,mod2c,mod3l,mod3a,mod3c,mod4l,mod4a,mod4c,mod5l,mod5a,mod5c,mod6l,mod6a,mod6c,mod7l,mod7a,mod7c,mod8l,mod8a,mod8c,mod9l,mod9a,mod9c,mod10l,mod10a,mod10c,mod11l,mod11a,mod11c,mod12l,mod12a,mod12c,level,id FROM training WHERE regno LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
        regnotxt.setText(rs.getString("regno"));
        courcetxt .setText(rs.getString("cource"));
        du1txt.setDate(rs.getDate("du1"));
        du2txt .setDate(rs.getDate("du2"));
        mod1txt.setText(rs.getString("mod1"));
        mod2txt.setText(rs.getString("mod2"));
        mod3txt.setText(rs.getString("mod3"));
        mod4txt.setText(rs.getString("mod4"));
        mod5txt.setText(rs.getString("mod5"));
        mod6txt.setText(rs.getString("mod6"));
        mod7txt.setText(rs.getString("mod7"));
        mod8txt.setText(rs.getString("mod8"));
        mod9txt.setText(rs.getString("mod9"));
        mod10txt.setText(rs.getString("mod10"));
        mod11txt.setText(rs.getString("mod11"));
        mod12txt.setText(rs.getString("mod12"));
        mod1ltxt.setText(rs.getString("mod1l"));
        mod1atxt.setText(rs.getString("mod1a"));
        mod1ctxt.setText(rs.getString("mod1c"));
        mod2ltxt.setText(rs.getString("mod2l"));
        mod2atxt.setText(rs.getString("mod2a"));
        mod2ctxt.setText(rs.getString("mod2c"));
        mod3ltxt.setText(rs.getString("mod3l"));
        mod3atxt.setText(rs.getString("mod3a"));
        mod3ctxt.setText(rs.getString("mod3c"));
        mod4ltxt.setText(rs.getString("mod4l"));
        mod4atxt.setText(rs.getString("mod4a"));
        mod4ctxt.setText(rs.getString("mod4c"));
        mod5ltxt.setText(rs.getString("mod5l"));
        mod5atxt.setText(rs.getString("mod5a"));
        mod5ctxt.setText(rs.getString("mod5c"));
        mod6ltxt.setText(rs.getString("mod6l"));
        mod6atxt.setText(rs.getString("mod6a"));
        mod6ctxt.setText(rs.getString("mod6c"));
        mod7ltxt.setText(rs.getString("mod7l"));
        mod7atxt.setText(rs.getString("mod7a"));
        mod7ctxt.setText(rs.getString("mod7c"));
        mod8ltxt.setText(rs.getString("mod8l"));
        mod8atxt.setText(rs.getString("mod8a"));
        mod8ctxt.setText(rs.getString("mod8c"));
        mod9ltxt.setText(rs.getString("mod9l"));
        mod9atxt.setText(rs.getString("mod9a"));
        mod9ctxt.setText(rs.getString("mod9c"));
        mod10ltxt.setText(rs.getString("mod10l"));
        mod10atxt.setText(rs.getString("mod10a"));
        mod10ctxt.setText(rs.getString("mod10c"));
        mod11ltxt.setText(rs.getString("mod11l"));
        mod11atxt.setText(rs.getString("mod11a"));
        mod11ctxt.setText(rs.getString("mod11c"));
        mod12ltxt.setText(rs.getString("mod12l"));
        mod12atxt.setText(rs.getString("mod12a"));
        mod12ctxt.setText(rs.getString("mod12c"));
        leveltxt.setText(rs.getString("level"));
        idtxt.setText(rs.getString("id"));
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     }}
//------------------------------------------------------------------------------------------------- 
public void update(){
    savedata();
            try { 
        String squpdate = "UPDATE training SET regno=?,cource=?,du1=?,du2=?,mod1=?,mod2=?,mod3=?,mod4=?,mod5=?,mod6=?,mod7=?,mod8=?,mod9=?,mod10=?,mod11=?,mod12=?,mod1l=?,mod1a=?,mod1c=?,mod2l=?,mod2a=?,mod2c=?,mod3l=?,mod3a=?,mod3c=?,mod4l=?,mod4a=?,mod4c=?,mod5l=?,mod5a=?,mod5c=?,mod6l=?,mod6a=?,mod6c=?,mod7l=?,mod7a=?,mod7c=?,mod8l=?,mod8a=?,mod8c=?,mod9l=?,mod9a=?,mod9c=?,mod10l=?,mod10a=?,mod10c=?,mod11l=?,mod11a=?,mod11c=?,mod12l=?,mod12a=?,mod12c=?,level=? WHERE id='"+idtxt.getText()+"'";
        pst = (PreparedStatement) conn.prepareStatement(squpdate);
        pst.setString(1,regno);
        pst.setString(2,cource);
        pst.setString(3,du1);
        pst.setString(4,du2);
        pst.setString(5,mod1);
        pst.setString(6,mod2);
        pst.setString(7,mod3);
        pst.setString(8,mod4);
        pst.setString(9,mod5);
        pst.setString(10,mod6);
        pst.setString(11,mod7);
        pst.setString(12,mod8);
        pst.setString(13,mod9);
        pst.setString(14,mod10);
        pst.setString(15,mod11);
        pst.setString(16,mod12);
        pst.setString(17,mod1l);
        pst.setString(18,mod1a);
        pst.setString(19,mod1c);
        pst.setString(20,mod2l);
        pst.setString(21,mod2a);
        pst.setString(22,mod2c);
        pst.setString(23,mod3l);
        pst.setString(24,mod3a);
        pst.setString(25,mod3c);
        pst.setString(26,mod4l);
        pst.setString(27,mod4a);
        pst.setString(28,mod4c);
        pst.setString(29,mod5l);
        pst.setString(30,mod5a);
        pst.setString(31,mod5c);
        pst.setString(32,mod6l);
        pst.setString(33,mod6a);
        pst.setString(34,mod6c);
        pst.setString(35,mod7l);
        pst.setString(36,mod7a);
        pst.setString(37,mod7c);
        pst.setString(38,mod8l);
        pst.setString(39,mod8a);
        pst.setString(40,mod8c);
        pst.setString(41,mod9l);
        pst.setString(42,mod9a);
        pst.setString(43,mod9c);
        pst.setString(44,mod10l);
        pst.setString(45,mod10a);
        pst.setString(46,mod10c);
        pst.setString(47,mod11l);
        pst.setString(48,mod11a);
        pst.setString(49,mod11c);
        pst.setString(50,mod12l);
        pst.setString(51,mod12a);
        pst.setString(52,mod12c);
        pst.setString(53,level);
        pst.execute();
        JOptionPane.showMessageDialog(null,"Update success..");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }}
//------------------------------------------------------------------------------------------------- 
    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
        int check = JOptionPane.showConfirmDialog(null, "Do you want to delete");

        if(check ==0){
            String id = idtxt.getText();
            try {
                String sql = "DELETE FROM training WHERE id='"+id+"'";
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "deleted..!");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "delete error..!");
            }
        }
        clear();
        printtxt.hide();
        viewbtn.show(true);
    }//GEN-LAST:event_deletebtnActionPerformed
//-------------------------------------------------------------------------------------------------
public void print(){
        resipttxt.append("\t\tTRAINING DETAILS \n"+
                "===============================================================================\n"+
                "Registration Number:"+"\t"+regnotxt.getText()+"\n"+
                "Cource:"+"\t\t"+courcetxt.getText()+"\n"+
                "Cource Duration:"+"\t"+du1txt.getDate()+du2txt.getDate()+"\n\n"+
                "\t\tFINAL ASSIGNMENTS COMPLETION RECORDS \n"+
                "===============================================================================\n"+
                "Mod 01\t"+mod1txt.getText()+"\n"+
                "Mod 02\t"+mod2txt.getText()+"\n"+
                "Mod 03\t"+mod3txt.getText()+"\n"+
                "Mod 04\t"+mod4txt.getText()+"\n"+
                "Mod 05\t"+mod5txt.getText()+"\n"+
                "Mod 06\t"+mod6txt.getText()+"\n"+
                "Mod 07\t"+mod7txt.getText()+"\n"+
                "Mod 08\t"+mod8txt.getText()+"\n"+
                "Mod 09\t"+mod9txt.getText()+"\n"+
                "Mod 10\t"+mod10txt.getText()+"\n"+
                "Mod 11\t"+mod11txt.getText()+"\n"+
                "Mod 12\t"+mod12txt.getText()+"\n\n"+
                
                "\t\tTRAINING RECORDS\n"+
                "=================================================================================================\n\n"+
                "MODULE\tLESSON\tASSIGNMENTS\tCERTIFY\n"+
                "-------------------------------------------------------------------------------------------------------------------------------------------------------------\n"+
                "Mod 01\t"+mod1ltxt.getText()+"\t"+mod1atxt.getText()+"\t\t"+mod1ctxt.getText()+"\n"+
                "Mod 02\t"+mod2ltxt.getText()+"\t"+mod2atxt.getText()+"\t\t"+mod2ctxt.getText()+"\n"+
                "Mod 03\t"+mod3ltxt.getText()+"\t"+mod3atxt.getText()+"\t\t"+mod3ctxt.getText()+"\n"+
                "Mod 04\t"+mod4ltxt.getText()+"\t"+mod4atxt.getText()+"\t\t"+mod4ctxt.getText()+"\n"+
                "Mod 05\t"+mod5ltxt.getText()+"\t"+mod5atxt.getText()+"\t\t"+mod5ctxt.getText()+"\n"+
                "Mod 06\t"+mod6ltxt.getText()+"\t"+mod6atxt.getText()+"\t\t"+mod6ctxt.getText()+"\n"+
                "Mod 07\t"+mod7ltxt.getText()+"\t"+mod7atxt.getText()+"\t\t"+mod7ctxt.getText()+"\n"+
                "Mod 08\t"+mod8ltxt.getText()+"\t"+mod8atxt.getText()+"\t\t"+mod8ctxt.getText()+"\n"+
                "Mod 09\t"+mod8ltxt.getText()+"\t"+mod8atxt.getText()+"\t\t"+mod8ctxt.getText()+"\n"+
                "Mod 10\t"+mod9ltxt.getText()+"\t"+mod9atxt.getText()+"\t\t"+mod9ctxt.getText()+"\n"+
                "Mod 11\t"+mod10ltxt.getText()+"\t"+mod10atxt.getText()+"\t\t"+mod10ctxt.getText()+"\n"+
                "Mod 12\t"+mod11ltxt.getText()+"\t"+mod11atxt.getText()+"\t\t"+mod11ctxt.getText()+"\n\n"
 
              
                
                                         
                );
}
//-------------------------------------------------------------------------------------------------  
    
    
    private void regnotxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_regnotxtKeyReleased
        autocomplete();
    }//GEN-LAST:event_regnotxtKeyReleased

    private void cleartxt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cleartxt1ActionPerformed
        clear();
        printtxt.hide();
        viewbtn.show(true);
    }//GEN-LAST:event_cleartxt1ActionPerformed

    private void totalbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalbtnActionPerformed

    }//GEN-LAST:event_totalbtnActionPerformed

    private void leveltxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_leveltxtKeyReleased

    }//GEN-LAST:event_leveltxtKeyReleased

    private void viewbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewbtnActionPerformed
        print();
        printtxt.show(true);
        viewbtn.hide();
    }//GEN-LAST:event_viewbtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel avglbl;
    private javax.swing.JButton cleartxt1;
    private javax.swing.JTextField courcetxt;
    private javax.swing.JButton deletebtn;
    private com.toedter.calendar.JDateChooser du1txt;
    private com.toedter.calendar.JDateChooser du2txt;
    private javax.swing.JLabel idtxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField leveltxt;
    private javax.swing.JTextField mod10atxt;
    private javax.swing.JTextField mod10ctxt;
    private javax.swing.JTextField mod10ltxt;
    private javax.swing.JTextField mod10txt;
    private javax.swing.JTextField mod11atxt;
    private javax.swing.JTextField mod11ctxt;
    private javax.swing.JTextField mod11ltxt;
    private javax.swing.JTextField mod11txt;
    private javax.swing.JTextField mod12atxt;
    private javax.swing.JTextField mod12ctxt;
    private javax.swing.JTextField mod12ltxt;
    private javax.swing.JTextField mod12txt;
    private javax.swing.JTextField mod1atxt;
    private javax.swing.JTextField mod1ctxt;
    private javax.swing.JTextField mod1ltxt;
    private javax.swing.JTextField mod1txt;
    private javax.swing.JTextField mod2atxt;
    private javax.swing.JTextField mod2ctxt;
    private javax.swing.JTextField mod2ltxt;
    private javax.swing.JTextField mod2txt;
    private javax.swing.JTextField mod3atxt;
    private javax.swing.JTextField mod3ctxt;
    private javax.swing.JTextField mod3ltxt;
    private javax.swing.JTextField mod3txt;
    private javax.swing.JTextField mod4atxt;
    private javax.swing.JTextField mod4ctxt;
    private javax.swing.JTextField mod4ltxt;
    private javax.swing.JTextField mod4txt;
    private javax.swing.JTextField mod5atxt;
    private javax.swing.JTextField mod5ctxt;
    private javax.swing.JTextField mod5ltxt;
    private javax.swing.JTextField mod5txt;
    private javax.swing.JTextField mod6atxt;
    private javax.swing.JTextField mod6ctxt;
    private javax.swing.JTextField mod6ltxt;
    private javax.swing.JTextField mod6txt;
    private javax.swing.JTextField mod7atxt;
    private javax.swing.JTextField mod7ctxt;
    private javax.swing.JTextField mod7ltxt;
    private javax.swing.JTextField mod7txt;
    private javax.swing.JTextField mod8atxt;
    private javax.swing.JTextField mod8ctxt;
    private javax.swing.JTextField mod8ltxt;
    private javax.swing.JTextField mod8txt;
    private javax.swing.JTextField mod9atxt;
    private javax.swing.JTextField mod9ctxt;
    private javax.swing.JTextField mod9ltxt;
    private javax.swing.JTextField mod9txt;
    private javax.swing.JButton printtxt;
    private javax.swing.JButton registertxt;
    private javax.swing.JTextField regnotxt;
    private javax.swing.JTextArea resipttxt;
    private javax.swing.JTextField searchboxtxt;
    private javax.swing.JButton totalbtn;
    private javax.swing.JLabel totallbl1;
    private javax.swing.JButton updatebtn;
    private javax.swing.JButton viewbtn;
    // End of variables declaration//GEN-END:variables
}
