package INTERFACES;
import CODES.DBconnect;
import java.awt.Color;
import java.awt.Image;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class payments_page extends javax.swing.JPanel {
    Connection conn;
    PreparedStatement pst=null;
    ResultSet rs = null;

    public payments_page() {
        initComponents();
        conn = DBconnect.connect();
        printtxt1.hide();
    }

    @SuppressWarnings("unchecked")
    
    //-------------------------------------------------------------------------------------------------
public void autocomplete(){       
        String search = tnotxt.getText();     
        try {
            String sql = "SELECT cource FROM register WHERE traineeno LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
            
            courcetxt.setText(rs.getString("cource"));
            
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     } }
    
//-------------------------------------------------------------------------------------------------                            
public void clear(){
        searchboxtxt.setText("");
        tnotxt.setText("");
        courcetxt.setText("");
        du1txt.setCalendar(null);
        du2txt.setCalendar(null);
        regfeetxt.setSelectedIndex(-1);
        cfeetxt.setSelectedIndex(-1);
        noitxt.setSelectedIndex(-1);
        mitxt.setSelectedIndex(-1);
        cf1atxt.setText("");
        cf1dtxt.setText("");
        cf1ctxt.setText("");
        cf2atxt.setText("");
        cf2dtxt.setText("");
        cf2ctxt.setText("");
        cf3atxt.setText("");
        cf3dtxt.setText("");
        cf3ctxt.setText("");
        cf4atxt.setText("");
        cf4dtxt.setText("");
        cf4ctxt.setText("");
        cf5atxt.setText("");
        cf5dtxt.setText("");
        cf5ctxt.setText("");
        cf6atxt.setText("");
        cf6dtxt.setText("");
        cf6ctxt.setText("");
        reatxt.setText("");
        redtxt.setText("");
        rectxt.setText("");
        totaltxt.setText("");
        mod1txt.setText("");
        mod2txt.setText("");
        mod3txt.setText("");
        mod4txt.setText("");
        mod5txt.setText("");
        mod6txt.setText("");
        mod7txt.setText("");
        mod8txt.setText("");
        mod9txt.setText("");
        mod10txt.setText("");
        mod11txt.setText("");
        mod12txt.setText("");
        resipttxt.setText("");
        idtxt.setText("");
        printtxt1.hide();
        viewbtn.show(true);
    }
//-------------------------------------------------------------------------------------------------            
   
        String regno;
        String cource;
        String du1;
        String du2;
        String regfee;
        String cfee;
        String noi;
        String mi;
        String cf1a;
        String cf1d;
        String cf1c;
        String cf2a;
        String cf2d;
        String cf2c;
        String cf3a;
        String cf3d;
        String cf3c;
        String cf4a;
        String cf4d;
        String cf4c;
        String cf5a;
        String cf5d;
        String cf5c;
        String cf6a;
        String cf6d;
        String cf6c;
        String rea;
        String red;
        String rec;
        String total;
        String mod1;
        String mod2;
        String mod3;
        String mod4;
        String mod5;
        String mod6;
        String mod7;
        String mod8;
        String mod9;
        String mod10;
        String mod11;
        String mod12;        
        
//-------------------------------------------------------------------------------------------------
private void savedata(){
    
    regno = tnotxt.getText();
    cource = courcetxt.getText();
    SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
    du1 = dateformat.format(du1txt.getDate());
    SimpleDateFormat dateformat2 = new SimpleDateFormat("yyyy-MM-dd");
    du2 = dateformat2.format(du2txt.getDate());
    regfee = regfeetxt.getSelectedItem().toString();
    cfee = cfeetxt.getSelectedItem().toString();
    noi = noitxt.getSelectedItem().toString();
    mi = mitxt.getSelectedItem().toString();
    cf1a=cf1atxt.getText();
    cf1d=cf1dtxt.getText();
    cf2d=cf2dtxt.getText();
    cf3d=cf3dtxt.getText();
    cf4d=cf4dtxt.getText();
    cf5d=cf5dtxt.getText();
    cf6d=cf6dtxt.getText(); 
    red=redtxt.getText();
    cf1c=cf1ctxt.getText();
    cf2a=cf2atxt.getText();
    cf2c=cf2ctxt.getText();
    cf3a=cf3atxt.getText();
    cf3c=cf3ctxt.getText();
    cf4a=cf4atxt.getText();
    cf4c=cf4ctxt.getText();
    cf5a=cf5atxt.getText();
    cf5c=cf5ctxt.getText();
    cf6a=cf6atxt.getText();
    cf6c=cf6ctxt.getText();
    rea=reatxt.getText();
    rec=rectxt.getText();
    total=totaltxt.getText();
    mod1=mod1txt.getText();
    mod2=mod2txt.getText();
    mod3=mod3txt.getText();
    mod4=mod4txt.getText();
    mod5=mod5txt.getText();
    mod6=mod6txt.getText();
    mod7=mod7txt.getText();
    mod8=mod8txt.getText();
    mod9=mod9txt.getText();
    mod10=mod10txt.getText();
    mod11=mod11txt.getText();
    mod12=mod12txt.getText();
    }
//-------------------------------------------------------------------------------------------------
public void update(){
            try { 
        String squpdate = "UPDATE payments SET  regno=?,cource=?,du1=?,du2=?,regfee=?,cfee=?,noi=?,mi=?,cf1a=?,cf1d=?,cf1c=?,cf2a=?,cf2d=?,cf2c=?,cf3a=?,cf3d=?,cf3c=?,cf4a=?,cf4d=?,cf4c=?,cf5a=?,cf5d=?,cf5c=?,cf6a=?,cf6d=?,cf6c=?,rea=?,red=?,rec=?,total=?,mod1=?,mod2=?,mod3=?,mod4=?,mod5=?,mod6=?,mod7=?,mod8=?,mod9=?,mod10=?,mod11=?,mod12=? WHERE id='"+idtxt.getText()+"'";
        pst = (PreparedStatement) conn.prepareStatement(squpdate);
        pst.setString (1,regno);
        pst.setString (2,cource);
        pst.setString (3,du1);
        pst.setString (4,du2);
        pst.setString (5,regfee);
        pst.setString (6,cfee);
        pst.setString (7,noi);
        pst.setString (8,mi);  
        pst.setString (9,cf1a);
        pst.setString (10,cf1d);
        pst.setString (11,cf1c);
        pst.setString (12,cf2a);
        pst.setString (13,cf2d);
        pst.setString (14,cf2c);
        pst.setString (15,cf3a);
        pst.setString (16,cf3d);
        pst.setString (17,cf3c);
        pst.setString (18,cf4a);
        pst.setString (19,cf4d);
        pst.setString (20,cf4c);
        pst.setString (21,cf5a);
        pst.setString (22,cf5d);
        pst.setString (23,cf5c);
        pst.setString (24,cf6a);  
        pst.setString (25,cf6d);
        pst.setString (26,cf6c);
        pst.setString (27,rea);
        pst.setString (28,red);
        pst.setString (29,rec);
        pst.setString (30,total);
        pst.setString (31,mod1);
        pst.setString (32,mod2);
        pst.setString (33,mod3);
        pst.setString (34,mod4);
        pst.setString (35,mod5);
        pst.setString (36,mod6);  
        pst.setString (37,mod7);
        pst.setString (38,mod8);
        pst.setString (39,mod9);
        pst.setString (40,mod10);
        pst.setString (41,mod11);
        pst.setString (42,mod12);
        pst.execute();
        JOptionPane.showMessageDialog(null,"Update success..");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }}
//-------------------------------------------------------------------------------------------------              
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        searchboxtxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        idtxt = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        regfeetxt = new javax.swing.JComboBox();
        courcetxt = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        du2txt = new com.toedter.calendar.JDateChooser();
        updatebtn = new javax.swing.JButton();
        registertxt = new javax.swing.JButton();
        deletebtn = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        du1txt = new com.toedter.calendar.JDateChooser();
        cfeetxt = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        noitxt = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        mitxt = new javax.swing.JComboBox();
        jLabel12 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        mod1txt = new javax.swing.JTextField();
        mod2txt = new javax.swing.JTextField();
        mod3txt = new javax.swing.JTextField();
        mod4txt = new javax.swing.JTextField();
        mod5txt = new javax.swing.JTextField();
        mod6txt = new javax.swing.JTextField();
        mod7txt = new javax.swing.JTextField();
        mod8txt = new javax.swing.JTextField();
        mod12txt = new javax.swing.JTextField();
        mod11txt = new javax.swing.JTextField();
        mod10txt = new javax.swing.JTextField();
        mod9txt = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        cf1ctxt = new javax.swing.JTextField();
        cf2ctxt = new javax.swing.JTextField();
        cf3ctxt = new javax.swing.JTextField();
        cf4ctxt = new javax.swing.JTextField();
        cf5ctxt = new javax.swing.JTextField();
        cf6ctxt = new javax.swing.JTextField();
        rectxt = new javax.swing.JTextField();
        jPanel20 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        cf3atxt = new javax.swing.JTextField();
        cf1atxt = new javax.swing.JTextField();
        cf2atxt = new javax.swing.JTextField();
        reatxt = new javax.swing.JTextField();
        cf6atxt = new javax.swing.JTextField();
        cf5atxt = new javax.swing.JTextField();
        cf4atxt = new javax.swing.JTextField();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        cf1dtxt = new javax.swing.JTextField();
        cf2dtxt = new javax.swing.JTextField();
        cf3dtxt = new javax.swing.JTextField();
        cf4dtxt = new javax.swing.JTextField();
        cf5dtxt = new javax.swing.JTextField();
        cf6dtxt = new javax.swing.JTextField();
        redtxt = new javax.swing.JTextField();
        totaltxt = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        totbtn = new javax.swing.JButton();
        tnotxt = new javax.swing.JTextField();
        cleartxt1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        resipttxt = new javax.swing.JTextArea();
        printtxt1 = new javax.swing.JButton();
        viewbtn = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 153, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Payments Form");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        searchboxtxt.setToolTipText("Enter Registration No"); // NOI18N
        searchboxtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchboxtxtKeyReleased(evt);
            }
        });
        jPanel2.add(searchboxtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 10, 250, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/search-2-24.png"))); // NOI18N
        jLabel2.setText("Search -");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 50));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel6.setText("Register fee(Rs)");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, -1, 30));

        idtxt.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        idtxt.setText("ID");
        jPanel1.add(idtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, 30));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel9.setText("Registration Number");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, 30));

        regfeetxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "500.00", "600.00", "800.00" }));
        jPanel1.add(regfeetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 310, 470, 30));

        courcetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                courcetxtKeyReleased(evt);
            }
        });
        jPanel1.add(courcetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 470, 30));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel13.setText("To");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 250, -1, -1));

        du2txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(du2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 140, 30));

        updatebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        updatebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/available-updates-24.png"))); // NOI18N
        updatebtn.setText("UPDATE");
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        jPanel1.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 990, 280, 40));

        registertxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        registertxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/us-dollar-24.png"))); // NOI18N
        registertxt.setText("ADD PAYMENTS");
        registertxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registertxtMouseClicked(evt);
            }
        });
        registertxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registertxtActionPerformed(evt);
            }
        });
        jPanel1.add(registertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 990, 280, 40));

        deletebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        deletebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/delete-24.png"))); // NOI18N
        deletebtn.setText("DELETE");
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        jPanel1.add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 1040, 280, 40));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel28.setText("Cource Duration");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, -1, 20));

        du1txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(du1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, 140, 30));

        cfeetxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "5000.00", "10000.00", "12000.00", "18000.00", " " }));
        jPanel1.add(cfeetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 370, 470, 30));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel10.setText("Cource fee(Rs)");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, -1, 30));

        noitxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "4", "6" }));
        jPanel1.add(noitxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 430, 470, 30));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel11.setText("No Of Installments");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, -1, 30));

        mitxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1250.00", "2500.00", "3000.00" }));
        jPanel1.add(mitxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 490, 470, 30));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel12.setText("Monthly Installment");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, -1, 30));

        jPanel3.setBackground(new java.awt.Color(0, 153, 51));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel4.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel9.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel4.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel4.add(mod1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 230, 30));
        jPanel4.add(mod2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 230, 30));
        jPanel4.add(mod3txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 230, 30));
        jPanel4.add(mod4txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 230, 30));
        jPanel4.add(mod5txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 230, 30));
        jPanel4.add(mod6txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 230, 30));
        jPanel4.add(mod7txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 230, 30));
        jPanel4.add(mod8txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 230, 30));
        jPanel4.add(mod12txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 230, 30));
        jPanel4.add(mod11txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 230, 30));
        jPanel4.add(mod10txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 230, 30));
        jPanel4.add(mod9txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 230, 30));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 50, 250, 500));

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setText("MODULE 01");
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel15.setText("MODULE 02");
        jPanel5.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel16.setText("MODULE 03");
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel17.setText("MODULE 04");
        jPanel5.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel18.setText("MODULE 09");
        jPanel5.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, -1, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel19.setText("MODULE 10");
        jPanel5.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, -1, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel21.setText("MODULE 12");
        jPanel5.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, -1, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel22.setText("MODULE 11");
        jPanel5.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, -1, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel23.setText("MODULE 08");
        jPanel5.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, -1, -1));

        jLabel39.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel39.setText("MODULE 07");
        jPanel5.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, -1, -1));

        jLabel40.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel40.setText("MODULE 06");
        jPanel5.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        jLabel41.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel41.setText("MODULE 05");
        jPanel5.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 150, 500));

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel20.setText("COURSE MATERIALS ISSUING RECORDS");
        jPanel6.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 290, 30));

        jPanel3.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 410, 30));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 70, 430, 560));

        jPanel15.setBackground(new java.awt.Color(0, 153, 51));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel16.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel18.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel16.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel16.add(cf1ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 30));
        jPanel16.add(cf2ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 100, 30));
        jPanel16.add(cf3ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 100, 30));
        jPanel16.add(cf4ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 100, 30));
        jPanel16.add(cf5ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 100, 30));
        jPanel16.add(cf6ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 100, 30));
        jPanel16.add(rectxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 100, 30));

        jPanel15.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, 120, 310));

        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel25.setText("Cource fee(1)");
        jPanel20.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel26.setText("Cource fee(2)");
        jPanel20.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel27.setText("Cource fee(3)");
        jPanel20.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel29.setText("Cource fee(4)");
        jPanel20.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        jLabel30.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel30.setText("Cource fee(5)");
        jPanel20.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, -1));

        jLabel31.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel31.setText("Re Exam Fee");
        jPanel20.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, -1, -1));

        jLabel32.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel32.setText("Cource fee(6)");
        jPanel20.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, -1));

        jPanel15.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 130, 310));

        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel33.setText("TYPE");
        jPanel21.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 50, 30));

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel34.setText("AMOUNT");
        jPanel21.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, 100, 30));

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel35.setText("DATE");
        jPanel21.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 0, 50, 30));

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel36.setText("CERTIFY");
        jPanel21.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, 80, 30));

        jPanel15.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 560, 30));

        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cf3atxt.setText("0");
        jPanel22.add(cf3atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 110, 30));

        cf1atxt.setText("0");
        jPanel22.add(cf1atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 30));

        cf2atxt.setText("0");
        jPanel22.add(cf2atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 110, 30));

        reatxt.setText("0");
        jPanel22.add(reatxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 110, 30));

        cf6atxt.setText("0");
        jPanel22.add(cf6atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 110, 30));

        cf5atxt.setText("0");
        jPanel22.add(cf5atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 110, 30));

        cf4atxt.setText("0");
        jPanel22.add(cf4atxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 110, 30));

        jPanel15.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 130, 310));

        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel23.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel26.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel25.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel23.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel23.add(cf1dtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 130, 30));
        jPanel23.add(cf2dtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 130, 30));
        jPanel23.add(cf3dtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 130, 30));
        jPanel23.add(cf4dtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 130, 30));
        jPanel23.add(cf5dtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 130, 30));
        jPanel23.add(cf6dtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 130, 30));
        jPanel23.add(redtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 130, 30));

        jPanel15.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, 150, 310));

        totaltxt.setEditable(false);
        jPanel15.add(totaltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 400, 150, 30));

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("PAYMENTS RECORDS");
        jPanel15.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 200, 40));

        totbtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        totbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/calculator-5-24.png"))); // NOI18N
        totbtn.setText("Total");
        totbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totbtnActionPerformed(evt);
            }
        });
        jPanel15.add(totbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 400, 100, 33));

        jPanel1.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 540, 580, 440));

        tnotxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnotxtKeyReleased(evt);
            }
        });
        jPanel1.add(tnotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 470, 30));

        cleartxt1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cleartxt1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/x-mark-4-24.png"))); // NOI18N
        cleartxt1.setText("CLEAR");
        cleartxt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cleartxt1ActionPerformed(evt);
            }
        });
        jPanel1.add(cleartxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 1040, 280, 40));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel8.setText("Cource");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, -1, 30));

        resipttxt.setColumns(20);
        resipttxt.setRows(5);
        jScrollPane1.setViewportView(resipttxt);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 640, 410, 500));

        printtxt1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        printtxt1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/printer-24.png"))); // NOI18N
        printtxt1.setText("PRINT");
        printtxt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printtxt1ActionPerformed(evt);
            }
        });
        jPanel1.add(printtxt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 1150, 200, 40));

        viewbtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        viewbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/eye-2-32.png"))); // NOI18N
        viewbtn.setText("VIEW");
        viewbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewbtnMouseClicked(evt);
            }
        });
        viewbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewbtnActionPerformed(evt);
            }
        });
        jPanel1.add(viewbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 1150, 200, 40));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 1240));
    }// </editor-fold>//GEN-END:initComponents

    private void searchboxtxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchboxtxtKeyReleased
        if (searchboxtxt.getText().isEmpty()) {
            clear();
        }
        else{searchbox();};
        
    }//GEN-LAST:event_searchboxtxtKeyReleased

    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
        
        savedata();
        update();
    }//GEN-LAST:event_updatebtnActionPerformed

    private void registertxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registertxtMouseClicked

    }//GEN-LAST:event_registertxtMouseClicked
//-------------------------------------------------------------------------------------------------           
 public void searchbox(){       
        String search = searchboxtxt.getText();     
        try {
            String sql = "SELECT regno,cource,du1,du2,regfee,cfee,noi,mi,cf1a,cf1d,cf1c,cf2a,cf2d,cf2c,cf3a,cf3d,cf3c,cf4a,cf4d,cf4c,cf5a,cf5d,cf5c,cf6a,cf6d,cf6c,rea,red,rec,total,mod1,mod2,mod3,mod4,mod5,mod6,mod7,mod8,mod9,mod10,mod11,mod12,id FROM payments WHERE regno LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
            tnotxt.setText(rs.getString("regno"));
            courcetxt.setText(rs.getString("cource"));
            du1txt.setDate(rs.getDate("du1"));
            du2txt.setDate(rs.getDate("du2"));
            regfeetxt.setSelectedItem(rs.getString("regfee"));
            cfeetxt.setSelectedItem(rs.getString("cfee"));
            noitxt.setSelectedItem(rs.getString("noi"));
            mitxt.setSelectedItem(rs.getString("mi"));
            cf1atxt.setText(rs.getString("cf1a"));
            cf1dtxt.setText(rs.getString("cf1d"));
            cf1ctxt.setText(rs.getString("cf1c"));
            cf2atxt.setText(rs.getString("cf2a"));
            cf2dtxt.setText(rs.getString("cf2d"));
            cf2ctxt.setText(rs.getString("cf2c"));
            cf3atxt.setText(rs.getString("cf3a"));
            cf3dtxt.setText(rs.getString("cf3d"));
            cf3ctxt.setText(rs.getString("cf3c"));
            cf4atxt.setText(rs.getString("cf4a"));
            cf4dtxt.setText(rs.getString("cf4d"));
            cf4ctxt.setText(rs.getString("cf4c"));
            cf5atxt.setText(rs.getString("cf5a"));
            cf5dtxt.setText(rs.getString("cf5d"));
            cf5ctxt.setText(rs.getString("cf5c"));
            cf6atxt.setText(rs.getString("cf6a"));
            cf6dtxt.setText(rs.getString("cf6d"));
            cf6ctxt.setText(rs.getString("cf6c"));
            reatxt.setText(rs.getString("rea"));
            redtxt.setText(rs.getString("red"));
            rectxt.setText(rs.getString("rec"));
            totaltxt.setText(rs.getString("total"));
            mod1txt.setText(rs.getString("mod1"));
            mod2txt.setText(rs.getString("mod2"));
            mod3txt.setText(rs.getString("mod3"));
            mod4txt.setText(rs.getString("mod4"));
            mod5txt.setText(rs.getString("mod5"));
            mod6txt.setText(rs.getString("mod6"));
            mod7txt.setText(rs.getString("mod7"));
            mod8txt.setText(rs.getString("mod8"));
            mod8txt.setText(rs.getString("mod9"));
            mod10txt.setText(rs.getString("mod10"));
            mod11txt.setText(rs.getString("mod11"));
            mod12txt.setText(rs.getString("mod12"));
            idtxt.setText(rs.getString("id"));
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     } }
 //-------------------------------------------------------------------------------------------------
public void print(){
        resipttxt.append("\t\tPAYMENTS RECORDS \n"+
                "===================================================================\n\n"+
                "Registration Number:\t"+tnotxt.getText()+"\n"+
                "Course:\t\t"+courcetxt.getText()+"\n"+
                "Course Duration:\t"+du1txt.getDate()+du2txt.getDate()+"\n"+
                "Register fee(Rs):\t"+regfeetxt.getSelectedItem()+"\n"+
                "Course fee(Rs):\t"+cfeetxt.getSelectedItem()+"\n"+
                "No Of Installments:\t"+noitxt.getSelectedItem()+"\n"+
                "Monthly Installment:\t"+mitxt.getSelectedItem()+"\n\n"+
                 
                "TYPE\tAMOUNT\tDATE\tCERTIFY\n"+
                "---------------------------------------------------------------------------------------------------------------------------------------------------------------\n"+
                "Course fee(1):\t"+cf1atxt.getText()+
                "\t"+cf1dtxt.getText()+"\t"+
                cf1ctxt.getText()+"\n"+
                "Course fee(2):"+"\t"+cf2atxt.getText()+"\t"+
                cf2dtxt.getText()+"\t"+cf2ctxt.getText()+"\n"+
                "Course fee(3):"+"\t"+cf3atxt.getText()+"\t"+
                cf3dtxt.getText()+"\t"+
                cf3ctxt.getText()+"\n"+
                "Course fee(4):"+"\t"+cf4atxt.getText()+"\t"+
                cf4dtxt.getText()+"\t"+cf4ctxt.getText()+"\n"+
                "Course fee(5):"+"\t"+cf5atxt.getText()+"\t"+
                cf5dtxt.getText()+"\t"+
                cf5ctxt.getText()+"\n"+
                "Course fee(6):"+"\t"+cf6atxt.getText()+"\t"+
                cf6dtxt.getText()+"\t"+cf6ctxt.getText()+"\n"+
                "Re Exam Fee:"+"\t"+reatxt.getText()+"\t"+
                redtxt.getText()+"\t"+rectxt.getText()+"\n\n"+
                "Total Balance:"+totaltxt.getText()+"\n\n"+
                "\tCOURSE MATERIALS ISSUING RECORDS"+
                "\n===================================================================\n"+
                "MODULE 01:"+"\t\t"+mod1txt.getText()+"\n"+
                "MODULE 02:"+"\t\t"+mod2txt.getText()+"\n"+
                "MODULE 03:"+"\t\t"+mod3txt.getText()+"\n"+
                "MODULE 04:"+"\t\t"+mod4txt.getText()+"\n"+
                "MODULE 05:"+"\t\t"+mod5txt.getText()+"\n"+
                "MODULE 06:"+"\t\t"+mod6txt.getText()+"\n"+
                "MODULE 07:"+"\t\t"+mod7txt.getText()+"\n"+
                "MODULE 08:"+"\t\t"+mod8txt.getText()+"\n"+
                "MODULE 09:"+"\t\t"+mod9txt.getText()+"\n"+
                "MODULE 10:"+"\t\t"+mod10txt.getText()+"\n"+
                "MODULE 11:"+"\t\t"+mod11txt.getText()+"\n"+
                "MODULE 12:"+"\t\t"+mod12txt.getText()+"\n"
                  
        );}
//-------------------------------------------------------------------------------------------------  
    private void registertxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registertxtActionPerformed
        tot();
        savedata();
        try {
        String sql = "INSERT INTO payments (regno,cource,du1,du2,regfee,cfee,noi,mi,cf1a,cf1d,cf1c,cf2a,cf2d,cf2c,cf3a,cf3d,cf3c,cf4a,cf4d,cf4c,cf5a,cf5d,cf5c,cf6a,cf6d,cf6c,rea,red,rec,total,mod1,mod2,mod3,mod4,mod5,mod6,mod7,mod8,mod9,mod10,mod11,mod12)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        pst = conn.prepareStatement(sql);
        pst.setString(1,regno);
        pst.setString(2,cource);
        pst.setString(3,du1);
        pst.setString(4,du2);
        pst.setString(5,regfee);
        pst.setString(6,cfee);
        pst.setString(7,noi);
        pst.setString(8,mi);
        pst.setString(9,cf1a);
        pst.setString(10,cf1d);
        pst.setString(11,cf1c);
        pst.setString(12,cf2a);
        pst.setString(13,cf2d);
        pst.setString(14,cf2c);
        pst.setString(15,cf3a);
        pst.setString(16,cf3d);
        pst.setString(17,cf3c);
        pst.setString(18,cf4a);
        pst.setString(19,cf4d);
        pst.setString(20,cf4c);
        pst.setString(21,cf5a);
        pst.setString(22,cf5d);
        pst.setString(23,cf5c);
        pst.setString(24,cf6a);
        pst.setString(25,cf6d);
        pst.setString(26,cf6c);
        pst.setString(27,rea);
        pst.setString(28,red);
        pst.setString(29,rec);
        pst.setString(30,total);
        pst.setString(31,mod1);
        pst.setString(32,mod2);
        pst.setString(33,mod3);
        pst.setString(34,mod4);
        pst.setString(35,mod5);
        pst.setString(36,mod6);
        pst.setString(37,mod7);
        pst.setString(38,mod8);
        pst.setString(39,mod9);
        pst.setString(40,mod10);
        pst.setString(41,mod11);
        pst.setString(42,mod12);

        pst.execute();
        JOptionPane.showMessageDialog(null,"Data Insert Success!!!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Registration Number Is Already Exist !");
        }
        
    }//GEN-LAST:event_registertxtActionPerformed
//------------------------------------------------------------------------------------------------- 
    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
      int check = JOptionPane.showConfirmDialog(null, "Do you want to delete");

        if(check ==0){
            String id = idtxt.getText();
            try {
                String sql = "DELETE FROM payments WHERE id='"+id+"'";
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "deleted..!");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "delete error..!");
            }
        }
        clear();                                               
    }//GEN-LAST:event_deletebtnActionPerformed
//------------------------------------------------------------------------------------------------- 
    private void courcetxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_courcetxtKeyReleased
        
    }//GEN-LAST:event_courcetxtKeyReleased

    private void tnotxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnotxtKeyReleased
        autocomplete();
    }//GEN-LAST:event_tnotxtKeyReleased

    private void cleartxt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cleartxt1ActionPerformed
         clear();
         
    }//GEN-LAST:event_cleartxt1ActionPerformed

    private void printtxt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printtxt1ActionPerformed
         try {
            resipttxt.print();
        } catch (PrinterException ex) {
            Logger.getLogger(register_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_printtxt1ActionPerformed

    private void viewbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewbtnMouseClicked
        print();
        printtxt1.show(true);
        viewbtn.hide();
    }//GEN-LAST:event_viewbtnMouseClicked

    private void viewbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewbtnActionPerformed
        
    }//GEN-LAST:event_viewbtnActionPerformed
//------------------------------------------------------------------------------------------------- 
    public void tot(){
         String a1 = cf1atxt.getText();
         String a2 = cf2atxt.getText();
         String a3 = cf3atxt.getText();
         String a4 = cf4atxt.getText();
         String a5 = cf5atxt.getText();
         String a6 = cf6atxt.getText();
         String re = reatxt.getText();
         
         int x1 = Integer.parseInt(a1);
         int x2 = Integer.parseInt(a2);
         int x3 = Integer.parseInt(a3);
         int x4 = Integer.parseInt(a4);
         int x5 = Integer.parseInt(a5);
         int x6 = Integer.parseInt(a6);
         int x7 = Integer.parseInt(re);
         
         int sum = (x1+x2+x3+x4+x5+x6+x7);
         String total = Integer.toString(sum);
         totaltxt.setText(total);
    }
    
    private void totbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totbtnActionPerformed

       tot(); 

    }//GEN-LAST:event_totbtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cf1atxt;
    private javax.swing.JTextField cf1ctxt;
    private javax.swing.JTextField cf1dtxt;
    private javax.swing.JTextField cf2atxt;
    private javax.swing.JTextField cf2ctxt;
    private javax.swing.JTextField cf2dtxt;
    private javax.swing.JTextField cf3atxt;
    private javax.swing.JTextField cf3ctxt;
    private javax.swing.JTextField cf3dtxt;
    private javax.swing.JTextField cf4atxt;
    private javax.swing.JTextField cf4ctxt;
    private javax.swing.JTextField cf4dtxt;
    private javax.swing.JTextField cf5atxt;
    private javax.swing.JTextField cf5ctxt;
    private javax.swing.JTextField cf5dtxt;
    private javax.swing.JTextField cf6atxt;
    private javax.swing.JTextField cf6ctxt;
    private javax.swing.JTextField cf6dtxt;
    private javax.swing.JComboBox cfeetxt;
    private javax.swing.JButton cleartxt1;
    private javax.swing.JTextField courcetxt;
    private javax.swing.JButton deletebtn;
    private com.toedter.calendar.JDateChooser du1txt;
    private com.toedter.calendar.JDateChooser du2txt;
    private javax.swing.JLabel idtxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox mitxt;
    private javax.swing.JTextField mod10txt;
    private javax.swing.JTextField mod11txt;
    private javax.swing.JTextField mod12txt;
    private javax.swing.JTextField mod1txt;
    private javax.swing.JTextField mod2txt;
    private javax.swing.JTextField mod3txt;
    private javax.swing.JTextField mod4txt;
    private javax.swing.JTextField mod5txt;
    private javax.swing.JTextField mod6txt;
    private javax.swing.JTextField mod7txt;
    private javax.swing.JTextField mod8txt;
    private javax.swing.JTextField mod9txt;
    private javax.swing.JComboBox noitxt;
    private javax.swing.JButton printtxt1;
    private javax.swing.JTextField reatxt;
    private javax.swing.JTextField rectxt;
    private javax.swing.JTextField redtxt;
    private javax.swing.JComboBox regfeetxt;
    private javax.swing.JButton registertxt;
    private javax.swing.JTextArea resipttxt;
    private javax.swing.JTextField searchboxtxt;
    private javax.swing.JTextField tnotxt;
    private javax.swing.JTextField totaltxt;
    private javax.swing.JButton totbtn;
    private javax.swing.JButton updatebtn;
    private javax.swing.JButton viewbtn;
    // End of variables declaration//GEN-END:variables
}
