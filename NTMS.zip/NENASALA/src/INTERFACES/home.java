package INTERFACES;
import CODES.DBconnect;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class home extends javax.swing.JFrame {
    Connection conn;
    PreparedStatement pst = null;
    ResultSet rs = null;

    GridBagLayout layout = new GridBagLayout();
    dashbord_page p1;
    register_page p2;
    payments_page p3;
    examination_page p4;
    completion p5;
    training p6;

    public home() {
        initComponents();
        conn = DBconnect.connect();
        p1 = new dashbord_page();
        p2 = new register_page();
        p3 = new payments_page();
        p4 = new examination_page();
        p5 = new completion();
        p6 = new training();
        
                
        dynamic_panel.setLayout(layout);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx=0;
        c.gridy=0;
        dynamic_panel.add(p1,c);
        c.gridx=0;
        c.gridy=0;
        dynamic_panel.add(p2,c);
        dynamic_panel.add(p3,c);
        dynamic_panel.add(p4,c);
        dynamic_panel.add(p5,c);
        dynamic_panel.add(p6,c);
        
        p1.setVisible(true);
        p2.setVisible(false);
        p3.setVisible(false);
        p4.setVisible(false);
        p5.setVisible(false);
        p6.setVisible(false);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sidebar_panel = new javax.swing.JPanel();
        hide1 = new javax.swing.JLabel();
        register__button = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        payments_button = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        examination_button = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        completion_button = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        training_button = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        dashbord_button = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        setting_btn = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        home_panel_1 = new javax.swing.JPanel();
        nenasala_panel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        sidebar_panel_hide = new javax.swing.JPanel();
        hide2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        dynamic_panel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sidebar_panel.setBackground(new java.awt.Color(0, 153, 51));
        sidebar_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        hide1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/list-rich-32.png"))); // NOI18N
        hide1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hide1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide1MousePressed(evt);
            }
        });
        sidebar_panel.add(hide1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 40, 40));

        register__button.setBackground(new java.awt.Color(0, 153, 51));
        register__button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                register__buttonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                register__buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                register__buttonMouseExited(evt);
            }
        });
        register__button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/add-user.png"))); // NOI18N
        jLabel3.setText("REGISTRATION");
        register__button.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));
        register__button.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, -30, -1, -1));

        sidebar_panel.add(register__button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 220, 50));

        payments_button.setBackground(new java.awt.Color(0, 153, 51));
        payments_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                payments_buttonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                payments_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                payments_buttonMouseExited(evt);
            }
        });
        payments_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/money-bag-32.png"))); // NOI18N
        jLabel1.setText("PAYMENTS");
        payments_button.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        sidebar_panel.add(payments_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, 220, 50));

        examination_button.setBackground(new java.awt.Color(0, 153, 51));
        examination_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                examination_buttonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                examination_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                examination_buttonMouseExited(evt);
            }
        });
        examination_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/text-file-4-32.png"))); // NOI18N
        jLabel4.setText("EXAMINATION");
        examination_button.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        sidebar_panel.add(examination_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, 220, 50));

        completion_button.setBackground(new java.awt.Color(0, 153, 51));
        completion_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                completion_buttonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                completion_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                completion_buttonMouseExited(evt);
            }
        });
        completion_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/ok-32.png"))); // NOI18N
        jLabel5.setText("COMPLETION");
        completion_button.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        sidebar_panel.add(completion_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 470, 220, 50));

        training_button.setBackground(new java.awt.Color(0, 153, 51));
        training_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                training_buttonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                training_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                training_buttonMouseExited(evt);
            }
        });
        training_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/workers-32.png"))); // NOI18N
        jLabel6.setText("TRAINING");
        training_button.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        sidebar_panel.add(training_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 550, 220, 50));

        dashbord_button.setBackground(new java.awt.Color(0, 153, 51));
        dashbord_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dashbord_buttonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                dashbord_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                dashbord_buttonMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dashbord_buttonMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                dashbord_buttonMouseReleased(evt);
            }
        });
        dashbord_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/dashboard-32.png"))); // NOI18N
        jLabel7.setText("DASHBORD");
        dashbord_button.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        sidebar_panel.add(dashbord_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 220, 50));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/ns.png"))); // NOI18N
        sidebar_panel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 200, 140));

        setting_btn.setBackground(new java.awt.Color(0, 153, 51));
        setting_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                setting_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setting_btnMouseEntered(evt);
            }
        });
        setting_btn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/settings-5-32_1.png"))); // NOI18N
        jLabel9.setText("SETTING");
        setting_btn.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        sidebar_panel.add(setting_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 630, 220, 50));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        sidebar_panel.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 610, 200, 1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        sidebar_panel.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 200, 1));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        sidebar_panel.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 200, 1));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        sidebar_panel.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 200, 1));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        sidebar_panel.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 200, 1));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        sidebar_panel.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 530, 200, 1));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        sidebar_panel.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 690, 200, 1));

        getContentPane().add(sidebar_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 710));

        home_panel_1.setBackground(new java.awt.Color(255, 255, 255));
        home_panel_1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nenasala_panel.setBackground(new java.awt.Color(0, 153, 51));
        nenasala_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/logout-32.png"))); // NOI18N
        jLabel2.setText("Logout?");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        nenasala_panel.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 10, -1, 40));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/md.png"))); // NOI18N
        nenasala_panel.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 1180, 60));

        home_panel_1.add(nenasala_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 1120, 60));

        sidebar_panel_hide.setBackground(new java.awt.Color(0, 153, 51));
        sidebar_panel_hide.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        hide2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/list-rich-32.png"))); // NOI18N
        hide2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hide2MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide2MousePressed(evt);
            }
        });
        sidebar_panel_hide.add(hide2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 40, 40));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/ok.png"))); // NOI18N
        sidebar_panel_hide.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 460));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/ns.png"))); // NOI18N
        sidebar_panel_hide.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 200, 140));

        home_panel_1.add(sidebar_panel_hide, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 220, 710));

        dynamic_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jScrollPane1.setViewportView(dynamic_panel);

        home_panel_1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 70, 1120, 640));

        getContentPane().add(home_panel_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1360, 720));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
//------------------------------------------------------------------------------------------------- 
    private void dashbord_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashbord_buttonMouseEntered
       dashbord_button.setBackground(new Color(0,170,100));
       register__button.setBackground(new Color(0,153,51));
       payments_button.setBackground(new Color(0,153,51));
       examination_button.setBackground(new Color(0,153,51));
       training_button.setBackground(new Color(0,153,51));
       completion_button.setBackground(new Color(0,153,51));
       setting_btn.setBackground(new Color(0,153,51));
    }//GEN-LAST:event_dashbord_buttonMouseEntered

    private void dashbord_buttonMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashbord_buttonMouseReleased
       
    }//GEN-LAST:event_dashbord_buttonMouseReleased

    private void dashbord_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashbord_buttonMouseExited

    }//GEN-LAST:event_dashbord_buttonMouseExited
//------------------------------------------------------------------------------------------------- 
    private void register__buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_register__buttonMouseEntered
        register__button.setBackground(new Color(0,170,100));
        dashbord_button.setBackground(new Color(0,153,51));
        payments_button.setBackground(new Color(0,153,51));
        examination_button.setBackground(new Color(0,153,51));
        training_button.setBackground(new Color(0,153,51));
        completion_button.setBackground(new Color(0,153,51));
        setting_btn.setBackground(new Color(0,153,51));
    }//GEN-LAST:event_register__buttonMouseEntered

    private void register__buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_register__buttonMouseExited
       
    }//GEN-LAST:event_register__buttonMouseExited
//------------------------------------------------------------------------------------------------- 
    private void payments_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_payments_buttonMouseEntered
       payments_button.setBackground(new Color(0,170,100));
       dashbord_button.setBackground(new Color(0,153,51));
       register__button.setBackground(new Color(0,153,51));
       examination_button.setBackground(new Color(0,153,51));
       training_button.setBackground(new Color(0,153,51));
       completion_button.setBackground(new Color(0,153,51));
       setting_btn.setBackground(new Color(0,153,51));
       
    }//GEN-LAST:event_payments_buttonMouseEntered

    private void payments_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_payments_buttonMouseExited
        
    }//GEN-LAST:event_payments_buttonMouseExited
//------------------------------------------------------------------------------------------------- 
    private void examination_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_examination_buttonMouseEntered
        examination_button.setBackground(new Color(0,170,100));
        dashbord_button.setBackground(new Color(0,153,51));
        register__button.setBackground(new Color(0,153,51));
        payments_button.setBackground(new Color(0,153,51));
        training_button.setBackground(new Color(0,153,51));
        completion_button.setBackground(new Color(0,153,51));
        setting_btn.setBackground(new Color(0,153,51));
    }//GEN-LAST:event_examination_buttonMouseEntered

    private void examination_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_examination_buttonMouseExited
        
    }//GEN-LAST:event_examination_buttonMouseExited
//------------------------------------------------------------------------------------------------- 
    private void completion_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_completion_buttonMouseEntered
        completion_button.setBackground(new Color(0,170,100));
        dashbord_button.setBackground(new Color(0,153,51));
        register__button.setBackground(new Color(0,153,51));
        payments_button.setBackground(new Color(0,153,51));
        training_button.setBackground(new Color(0,153,51));
        examination_button.setBackground(new Color(0,153,51));
        setting_btn.setBackground(new Color(0,153,51));
    }//GEN-LAST:event_completion_buttonMouseEntered

    private void completion_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_completion_buttonMouseExited
        
    }//GEN-LAST:event_completion_buttonMouseExited
//------------------------------------------------------------------------------------------------- 
    private void training_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_training_buttonMouseEntered
       training_button.setBackground(new Color(0,170,100));
       dashbord_button.setBackground(new Color(0,153,51));
       register__button.setBackground(new Color(0,153,51));
       payments_button.setBackground(new Color(0,153,51));
       examination_button.setBackground(new Color(0,153,51));
       completion_button.setBackground(new Color(0,153,51));
       setting_btn.setBackground(new Color(0,153,51));
    }//GEN-LAST:event_training_buttonMouseEntered

    private void training_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_training_buttonMouseExited
        
    }//GEN-LAST:event_training_buttonMouseExited
//------------------------------------------------------------------------------------------------- 
    private void dashbord_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashbord_buttonMouseClicked
        dashbord_button.setBackground(Color.red);
        p1.setVisible(true);
        p2.setVisible(false);
        p3.setVisible(false);
        p4.setVisible(false);
        p5.setVisible(false);
        p6.setVisible(false);
    }//GEN-LAST:event_dashbord_buttonMouseClicked

    private void dashbord_buttonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashbord_buttonMousePressed

    }//GEN-LAST:event_dashbord_buttonMousePressed
//------------------------------------------------------------------------------------------------- 
    private void register__buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_register__buttonMouseClicked
        register__button.setBackground(Color.red);
        p1.setVisible(false);
        p2.setVisible(true);
        p3.setVisible(false);
        p4.setVisible(false);
        p5.setVisible(false);
        p6.setVisible(false);
    }//GEN-LAST:event_register__buttonMouseClicked
//------------------------------------------------------------------------------------------------- 
    private void payments_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_payments_buttonMouseClicked
        payments_button.setBackground(Color.red);
        p1.setVisible(false);
        p2.setVisible(false);
        p3.setVisible(true);
        p4.setVisible(false);
        p5.setVisible(false);
        p6.setVisible(false);
    }//GEN-LAST:event_payments_buttonMouseClicked
//------------------------------------------------------------------------------------------------- 
    private void examination_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_examination_buttonMouseClicked
        examination_button.setBackground(Color.red);
        p1.setVisible(false);
        p2.setVisible(false);
        p3.setVisible(false);
        p4.setVisible(true);
        p5.setVisible(false);
        p6.setVisible(false);
    }//GEN-LAST:event_examination_buttonMouseClicked
//------------------------------------------------------------------------------------------------- 
    private void completion_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_completion_buttonMouseClicked
        completion_button.setBackground(Color.red);
        p1.setVisible(false);
        p2.setVisible(false);
        p3.setVisible(false);
        p4.setVisible(false);
        p5.setVisible(true);
        p6.setVisible(false);
    }//GEN-LAST:event_completion_buttonMouseClicked
//------------------------------------------------------------------------------------------------- 
    private void training_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_training_buttonMouseClicked
        training_button.setBackground(Color.red);
        p1.setVisible(false);
        p2.setVisible(false);
        p3.setVisible(false);
        p4.setVisible(false);
        p5.setVisible(false);
        p6.setVisible(true);
    }//GEN-LAST:event_training_buttonMouseClicked
//-------------------------------------------------------------------------------------------------    
    private void hide1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide1MouseClicked
                
        if(x==220){
            sidebar_panel.setSize(220,710);
            Thread th= new Thread(){
                @Override
                public void run(){
                    try {
                        for(int i = 220; i>=0; i--){
                            Thread.sleep(1);
                            sidebar_panel.setSize(i,710);
                        }
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e);
                    }
                }
            };th.start();
            x=0;
        }
    }//GEN-LAST:event_hide1MouseClicked
//------------------------------------------------------------------------------------------------- 
    private void hide2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide2MouseClicked
                if(x==0){
            sidebar_panel.show();
            sidebar_panel.setSize(x,552);
            Thread th= new Thread(){
                @Override
                public void run(){
                    try {
                        for(int i = 0; i<=x; i++){
                            Thread.sleep(1);
                            sidebar_panel.setSize(i,710);
                        }
                    }
                    catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e);
                    }
                }
            };th.start();
            x=220;
        }
    }//GEN-LAST:event_hide2MouseClicked
int x=220;
    private void hide1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide1MousePressed
        hide1.setBackground(Color.red);
    }//GEN-LAST:event_hide1MousePressed

    private void hide2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide2MousePressed
        hide1.setBackground(Color.red);
    }//GEN-LAST:event_hide2MousePressed

    private void setting_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_setting_btnMouseClicked
        setting_btn.setBackground(Color.red);
        p1.setVisible(false);
        p2.setVisible(false);
        p3.setVisible(false);
        p4.setVisible(false);
        p5.setVisible(false);
        
        this.dispose();
        setting reg = new setting();
        reg.setVisible(true);
    }//GEN-LAST:event_setting_btnMouseClicked
//------------------------------------------------------------------------------------------------- 
    private void setting_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_setting_btnMouseEntered
       training_button.setBackground(new Color(0,153,51));
       dashbord_button.setBackground(new Color(0,153,51));
       register__button.setBackground(new Color(0,153,51));
       payments_button.setBackground(new Color(0,153,51));
       examination_button.setBackground(new Color(0,153,51));
       completion_button.setBackground(new Color(0,153,51));
       setting_btn.setBackground(new Color(0,170,100));
    }//GEN-LAST:event_setting_btnMouseEntered
//------------------------------------------------------------------------------------------------- 
    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked

        int check = JOptionPane.showConfirmDialog(null, "Do you want to Logout?");
        if(check ==0){
            try {
                login log=new login();
                log.setVisible(true);
                this.dispose();
            } catch (Exception e) {

            }
        }
    }//GEN-LAST:event_jLabel2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel completion_button;
    private javax.swing.JPanel dashbord_button;
    private javax.swing.JPanel dynamic_panel;
    private javax.swing.JPanel examination_button;
    private javax.swing.JLabel hide1;
    private javax.swing.JLabel hide2;
    private javax.swing.JPanel home_panel_1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel nenasala_panel;
    private javax.swing.JPanel payments_button;
    private javax.swing.JPanel register__button;
    private javax.swing.JPanel setting_btn;
    private javax.swing.JPanel sidebar_panel;
    private javax.swing.JPanel sidebar_panel_hide;
    private javax.swing.JPanel training_button;
    // End of variables declaration//GEN-END:variables
}
