package INTERFACES;
import CODES.DBconnect;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class examination_page extends javax.swing.JPanel {
Connection conn;
PreparedStatement pst=null;
    ResultSet rs = null;
    public examination_page() {
        initComponents();
        conn = DBconnect.connect();
        printtxt.hide();
    }
//------------------------------------------------------------------------------------------------- 
        String regno;
        String cource;
        String du1;
        String du2;
        String exd1;
        String exd2;
        String satex;
        String mod1l;
        String mod1m;
        String mod1g;
        String mod1c;
        String mod2l;
        String mod2m;
        String mod2g;
        String mod2c;
        String mod3l;
        String mod3m;
        String mod3g;
        String mod3c;
        String mod4l;
        String mod4m;
        String mod4g;
        String mod4c;
        String mod5l;
        String mod5m;
        String mod5g;
        String mod5c;
        String mod6l;
        String mod6m;
        String mod6g;
        String mod6c;
        String mod7l;
        String mod7m;
        String mod7g;
        String mod7c;
        String mod8l;
        String mod8m;
        String mod8g;
        String mod8c;
        String mod9l;
        String mod9m;
        String mod9g;
        String mod9c;
        String mod10l;
        String mod10m;
        String mod10g;
        String mod10c;
        String mod11l;
        String mod11m;
        String mod11g;
        String mod11c;
        String mod12l;
        String mod12m;
        String mod12g;
        String mod12c;
        String total;
        String avg;
        String grade;
//------------------------------------------------------------------------------------------------- 
    @SuppressWarnings("unchecked")
private void savedata(){
        regno = regnotxt.getText();
        cource = courcetxt.getText();
        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        du1 = dateformat.format(du1txt.getDate());
        du2 = dateformat.format(du2txt.getDate());
        exd1 = dateformat.format(exd1txt.getDate());
        exd2 = dateformat.format(exd2txt.getDate());
        satex = satextxt.getSelectedItem().toString();
        mod1l=mod1ltxt.getText();
        mod1m= mod1mtxt.getText();
        mod1g= mod1gtxt.getText();
        mod1c= mod1ctxt.getText();
        mod2l= mod2ltxt.getText();
        mod2m= mod2mtxt.getText();
        mod2g= mod2gtxt.getText();
        mod2c= mod2ctxt.getText();
        mod3l= mod3ltxt.getText();
        mod3m= mod3mtxt.getText();
        mod3g= mod3gtxt.getText();
        mod3c= mod3ctxt.getText();
       mod4l= mod4ltxt.getText();
       mod4m= mod4mtxt.getText();
       mod4g= mod4gtxt.getText();
       mod4c= mod4ctxt.getText();
       mod5l= mod5ltxt.getText();
       mod5m= mod5mtxt.getText();
       mod5g= mod5gtxt.getText();
       mod5c= mod5ctxt.getText();
       mod6l= mod6ltxt.getText();
       mod6m= mod6mtxt.getText();
       mod6g= mod6gtxt.getText();
       mod6c= mod6ctxt.getText();
       mod7l= mod7ltxt.getText();
       mod7m= mod7mtxt.getText();
       mod7g= mod7gtxt.getText();
       mod7c= mod7ctxt.getText();
       mod8l= mod8ltxt.getText();
       mod8m= mod8mtxt.getText();
       mod8g= mod8gtxt.getText();
       mod8c= mod8ctxt.getText();
       mod9l= mod9ltxt.getText();
       mod9m= mod9mtxt.getText();
       mod9g= mod9gtxt.getText();
       mod9c= mod9ctxt.getText();
       mod10l= mod10ltxt.getText();
       mod10m= mod10mtxt.getText();
       mod10g= mod10gtxt.getText();
       mod10c= mod10ctxt.getText();
       mod11l= mod11ltxt.getText();
       mod11m= mod11mtxt.getText();
       mod11g= mod11gtxt.getText();
       mod11c= mod11ctxt.getText();
       mod12l= mod12ltxt.getText();
       mod12m= mod12mtxt.getText();
       mod12g= mod12gtxt.getText();
       mod12c= mod12ctxt.getText();
       total=totaltxt.getText();
       avg=avgtxt.getText();
       grade=finalgradetxt.getText();
}
//-------------------------------------------------------------------------------------------------
public void searchbox(){       
        String search = searchboxtxt.getText();     
        try {
            String sql = "SELECT regno,cource,du1,du2,exd1,exd2,satexam,mod1l,mod1m,mod1g,mod1c,mod2l,mod2m,mod2g,mod2c,mod3l,mod3m,mod3g,mod3c,mod4l,mod4m ,mod4g ,mod4c ,mod5l,mod5m,mod5g,mod5c,mod6l,mod6m ,mod6g ,mod6c,mod7l ,mod7m ,mod7g ,mod7c ,mod8l ,mod8m ,mod8g ,mod8c ,mod9l ,mod9m ,mod9g ,mod9c,mod10l,mod10m,mod10g,mod10c,mod11l,mod11m,mod11g,mod11c,mod12l,mod12m,mod12g,mod12c,id,total,avg,grade FROM examination WHERE regno LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
        regnotxt.setText(rs.getString("regno"));
        courcetxt .setText(rs.getString("cource"));
        du1txt.setDate(rs.getDate("du1"));
        du2txt .setDate(rs.getDate("du2"));
        exd1txt .setDate(rs.getDate("exd1"));
        exd2txt .setDate(rs.getDate("exd2"));
        satextxt .setSelectedItem(rs.getString("satexam"));
        mod1ltxt.setText(rs.getString("mod1l"));
        mod1mtxt.setText(rs.getString("mod1m"));
        mod1gtxt.setText(rs.getString("mod1g"));
        mod1ctxt.setText(rs.getString("mod1c"));
        mod2ltxt.setText(rs.getString("mod2l"));
        mod2mtxt.setText(rs.getString("mod2m"));
        mod2gtxt.setText(rs.getString("mod2g"));
        mod2ctxt.setText(rs.getString("mod2c"));
        mod3ltxt .setText(rs.getString("mod3l"));
        mod3mtxt .setText(rs.getString("mod3m"));
        mod3gtxt .setText(rs.getString("mod3g"));
        mod3ctxt.setText(rs.getString("mod3c"));
       mod4ltxt.setText(rs.getString("mod4l"));
       mod4mtxt.setText(rs.getString("mod4m"));
       mod4gtxt.setText(rs.getString("mod4g"));
       mod4ctxt.setText(rs.getString("mod4c"));
       mod5ltxt .setText(rs.getString("mod5l"));
       mod5mtxt .setText(rs.getString("mod5m"));
       mod5gtxt .setText(rs.getString("mod5g"));
       mod5ctxt .setText(rs.getString("mod5c"));
       mod6ltxt .setText(rs.getString("mod6l"));
       mod6mtxt .setText(rs.getString("mod6m"));
       mod6gtxt .setText(rs.getString("mod6g"));
       mod6ctxt .setText(rs.getString("mod6c"));
       mod7ltxt .setText(rs.getString("mod7l"));
       mod7mtxt .setText(rs.getString("mod7m"));
       mod7gtxt .setText(rs.getString("mod7g"));
       mod7ctxt .setText(rs.getString("mod7c"));
       mod8ltxt .setText(rs.getString("mod8l"));
       mod8mtxt .setText(rs.getString("mod8m"));
       mod8gtxt .setText(rs.getString("mod8g"));
       mod8ctxt .setText(rs.getString("mod8c"));
       mod9ltxt .setText(rs.getString("mod9l"));
       mod9mtxt .setText(rs.getString("mod9m"));
       mod9gtxt .setText(rs.getString("mod9g"));
       mod9ctxt .setText(rs.getString("mod9c"));
       mod10ltxt .setText(rs.getString("mod10l"));
       mod10mtxt .setText(rs.getString("mod10m"));
       mod10gtxt .setText(rs.getString("mod10g"));
       mod10ctxt .setText(rs.getString("mod10c"));
       mod11ltxt .setText(rs.getString("mod11l"));
       mod11mtxt .setText(rs.getString("mod11m"));
       mod11gtxt .setText(rs.getString("mod11g"));
       mod11ctxt .setText(rs.getString("mod11c"));
       mod12ltxt .setText(rs.getString("mod12l"));
       mod12mtxt .setText(rs.getString("mod12m"));
       mod12gtxt .setText(rs.getString("mod12g"));
       mod12ctxt.setText(rs.getString("mod12c"));
       totaltxt.setText(rs.getString("total"));
       avgtxt.setText(rs.getString("avg"));
       finalgradetxt.setText(rs.getString("grade"));
       idtxt.setText(rs.getString("id")); 
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     } }
//-------------------------------------------------------------------------------------------------
public void update(){
    
            try { 
        savedata();
        String squpdate = "UPDATE examination SET regno=?,cource=?,du1=?,du2=?,exd1=?,exd2=?,satexam=?,mod1l=?,mod1m=?,mod1g=?,mod1c=?,mod2l=?,mod2m=?,mod2g=?,mod2c=?,mod3l=?,mod3m=?,mod3g=?,mod3c=?,mod4l=?,mod4m=? ,mod4g=? ,mod4c=? ,mod5l=?,mod5m=?,mod5g=?,mod5c=?,mod6l=?,mod6m=? ,mod6g=? ,mod6c=?,mod7l=? ,mod7m=? ,mod7g=? ,mod7c=?,mod8l=? ,mod8m=? ,mod8g=? ,mod8c=? ,mod9l=? ,mod9m=? ,mod9g=? ,mod9c=?,mod10l=?,mod10m=?,mod10g=?,mod10c=?,mod11l=?,mod11m=?,mod11g=?,mod11c=?,mod12l=?,mod12m=?,mod12g=?,mod12c=? WHERE id='"+idtxt.getText()+"'";
        pst = (PreparedStatement) conn.prepareStatement(squpdate);
        pst.setString(1,regno);
        pst.setString(2,cource);
        pst.setString(3,du1);
        pst.setString(4,du2);
        pst.setString(5,exd1);
        pst.setString(6,exd2);
        pst.setString(7,satex);
        pst.setString(8,mod1l);
        pst.setString(9,mod1m);
        pst.setString(10,mod1g);
        pst.setString(11,mod1c);
        pst.setString(12,mod2l);
        pst.setString(13,mod2m);
        pst.setString(14,mod2g);
        pst.setString(15,mod2c);
        pst.setString(16,mod3l);
        pst.setString(17,mod3m);
        pst.setString(18,mod3g);
        pst.setString(19,mod3c);
        pst.setString(20,mod4l);
        pst.setString(21,mod4m);
        pst.setString(22,mod4g);
        pst.setString(23,mod4c);
        pst.setString(24,mod5l);
        pst.setString(25,mod5m);
        pst.setString(26,mod5g);
        pst.setString(27,mod5c);
        pst.setString(28,mod6l);
        pst.setString(29,mod6m);
        pst.setString(30,mod6g);
        pst.setString(31,mod6c);
        pst.setString(32,mod7l);
        pst.setString(33,mod7m);
        pst.setString(34,mod7g);
        pst.setString(35,mod7c);
        pst.setString(36,mod8l);
        pst.setString(37,mod8m);
        pst.setString(38,mod8g);
        pst.setString(39,mod8c);
        pst.setString(40,mod9l);
        pst.setString(41,mod9m);
        pst.setString(42,mod9g);
        pst.setString(43,mod9c);
        pst.setString(44,mod10l);
        pst.setString(45,mod10m);
        pst.setString(46,mod10g);
        pst.setString(47,mod10c);
        pst.setString(48,mod11l);
        pst.setString(49,mod11m);
        pst.setString(50,mod11g);
        pst.setString(51,mod11c);
        pst.setString(52,mod12l);
        pst.setString(53,mod12m);
        pst.setString(54,mod12g);
        pst.setString(55,mod12c);
        pst.execute();
        JOptionPane.showMessageDialog(null,"Update success..");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }}
//-------------------------------------------------------------------------------------------------              
public void autocomplete(){       
        String search = regnotxt.getText();     
        try {
            String sql = "SELECT cource,du1,du2 FROM payments WHERE regno LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
            
            courcetxt.setText(rs.getString("cource"));
            du1txt.setDate(rs.getDate("du1"));
            du2txt.setDate(rs.getDate("du2"));
            
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     } }
    


//------------------------------------------------------------------------------------------------- 
public void print(){
        resipttxt.append("\t\tEXAMINATION RECORDS"+
                "\n========================================================================\n"+
                "Registration Number:\t"+regnotxt.getText()+"\n\n"+
                "Course:\t\t"+courcetxt.getText()+"\n\n"+
                "Course Duration:\t"+du1txt.getDate()+du2txt.getDate()+"\n\n"+
                "Exam Date:\t\t"+exd1txt.getDate()+exd2txt.getDate()+"\n\n"+
                "Sat For The Exam:\t"+satextxt.getSelectedItem()+"\n"+
                          
                 "\n=====================================================================\n\n"+
                "MODULE\tLESSON\tMARKS\tDRADE\tCERTIFY\n"+
                "-----------------------------------------------------------------------------------------------------------------------------------\n"+
                "MODULE(1):"+"\t"+mod1ltxt.getText()+"\t"+
                mod1mtxt.getText()+"\t"+
                mod1gtxt.getText()+"\t"+
                mod1ctxt.getText()+"\t"+"\n"+
                
                "MODULE(2):"+"\t"+mod2ltxt.getText()+"\t"+
                mod2mtxt.getText()+"\t"+
                mod2gtxt.getText()+"\t"+
                mod2ctxt.getText()+"\t"+"\n"+
                
                "MODULE(3):"+"\t"+mod3ltxt.getText()+"\t"+
                mod3mtxt.getText()+"\t"+
                mod3gtxt.getText()+"\t"+
                mod3ctxt.getText()+"\t"+"\n"+
                
                "MODULE(4):"+"\t"+mod4ltxt.getText()+"\t"+
                mod4mtxt.getText()+"\t"+
                mod4gtxt.getText()+"\t"+
                mod4ctxt.getText()+"\t"+"\n"+
                
                "MODULE(5):"+"\t"+mod5ltxt.getText()+"\t"+
                mod5mtxt.getText()+"\t"+
                mod5gtxt.getText()+"\t"+
                mod5ctxt.getText()+"\t"+"\n"+
                
                "MODULE(6):"+"\t"+mod6ltxt.getText()+"\t"+
                mod6mtxt.getText()+"\t"+
                mod6gtxt.getText()+"\t"+
                mod6ctxt.getText()+"\t"+"\n"+
                
                "MODULE(7):"+"\t"+mod7ltxt.getText()+"\t"+
                mod7mtxt.getText()+"\t"+
                mod7gtxt.getText()+"\t"+
                mod7ctxt.getText()+"\t"+"\n"+
                
                "MODULE(8):"+"\t"+mod8ltxt.getText()+"\t"+
                mod8mtxt.getText()+"\t"+
                mod8gtxt.getText()+"\t"+
                mod8ctxt.getText()+"\t"+"\n"+
                
                "MODULE(9):"+"\t"+mod9ltxt.getText()+"\t"+
                mod9mtxt.getText()+"\t"+
                mod9gtxt.getText()+"\t"+
                mod9ctxt.getText()+"\t"+"\n"+
                
                "MODULE(10):"+"\t"+mod10ltxt.getText()+"\t"+
                mod10mtxt.getText()+"\t"+
                mod10gtxt.getText()+"\t"+
                mod10ctxt.getText()+"\t"+"\n"+
                
                "MODULE(11):"+"\t"+mod11ltxt.getText()+"\t"+
                mod11mtxt.getText()+"\t"+
                mod11gtxt.getText()+"\t"+
                mod11ctxt.getText()+"\t"+"\n"+
                
                "MODULE(12):"+"\t"+mod12ltxt.getText()+"\t"+
                mod12mtxt.getText()+"\t"+
                mod12gtxt.getText()+"\t"+
                mod12ctxt.getText()+"\t"+"\n\n"+
                

                "Total Marks:"+totaltxt.getText()+"\n\n"+
                 "Average:"+avgtxt.getText()+"\n\n"+
                 "Final Grade:"+finalgradetxt.getText()+"\n"+
                "==================================================================================\n"
   
                  
        );}
//-------------------------------------------------------------------------------------------------  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        searchboxtxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        idtxt = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        satextxt = new javax.swing.JComboBox();
        courcetxt = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        du2txt = new com.toedter.calendar.JDateChooser();
        printtxt = new javax.swing.JButton();
        updatebtn = new javax.swing.JButton();
        registertxt = new javax.swing.JButton();
        deletebtn = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        du1txt = new com.toedter.calendar.JDateChooser();
        regnotxt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        exd2txt = new com.toedter.calendar.JDateChooser();
        jLabel44 = new javax.swing.JLabel();
        exd1txt = new com.toedter.calendar.JDateChooser();
        jPanel15 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        mod1ctxt = new javax.swing.JTextField();
        mod2ctxt = new javax.swing.JTextField();
        mod3ctxt = new javax.swing.JTextField();
        mod4ctxt = new javax.swing.JTextField();
        mod5ctxt = new javax.swing.JTextField();
        mod6ctxt = new javax.swing.JTextField();
        mod7ctxt = new javax.swing.JTextField();
        mod8ctxt = new javax.swing.JTextField();
        mod12ctxt = new javax.swing.JTextField();
        mod11ctxt = new javax.swing.JTextField();
        mod10ctxt = new javax.swing.JTextField();
        mod9ctxt = new javax.swing.JTextField();
        jPanel29 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        mod1ltxt = new javax.swing.JTextField();
        mod2ltxt = new javax.swing.JTextField();
        mod3ltxt = new javax.swing.JTextField();
        mod4ltxt = new javax.swing.JTextField();
        mod5ltxt = new javax.swing.JTextField();
        mod6ltxt = new javax.swing.JTextField();
        mod7ltxt = new javax.swing.JTextField();
        mod8ltxt = new javax.swing.JTextField();
        mod12ltxt = new javax.swing.JTextField();
        mod11ltxt = new javax.swing.JTextField();
        mod10ltxt = new javax.swing.JTextField();
        mod9ltxt = new javax.swing.JTextField();
        jPanel33 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        mod1gtxt = new javax.swing.JTextField();
        mod2gtxt = new javax.swing.JTextField();
        mod3gtxt = new javax.swing.JTextField();
        mod4gtxt = new javax.swing.JTextField();
        mod5gtxt = new javax.swing.JTextField();
        mod6gtxt = new javax.swing.JTextField();
        mod7gtxt = new javax.swing.JTextField();
        mod8gtxt = new javax.swing.JTextField();
        mod12gtxt = new javax.swing.JTextField();
        mod11gtxt = new javax.swing.JTextField();
        mod10gtxt = new javax.swing.JTextField();
        mod9gtxt = new javax.swing.JTextField();
        jPanel37 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jPanel39 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        mod1mtxt = new javax.swing.JTextField();
        mod2mtxt = new javax.swing.JTextField();
        mod3mtxt = new javax.swing.JTextField();
        mod4mtxt = new javax.swing.JTextField();
        mod5mtxt = new javax.swing.JTextField();
        mod6mtxt = new javax.swing.JTextField();
        mod7mtxt = new javax.swing.JTextField();
        mod8mtxt = new javax.swing.JTextField();
        mod12mtxt = new javax.swing.JTextField();
        mod11mtxt = new javax.swing.JTextField();
        mod10mtxt = new javax.swing.JTextField();
        mod9mtxt = new javax.swing.JTextField();
        totalbtn = new javax.swing.JButton();
        avglbl = new javax.swing.JLabel();
        totallbl1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        finalgradetxt = new javax.swing.JTextField();
        avgtxt = new javax.swing.JTextField();
        totaltxt = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        resipttxt = new javax.swing.JTextArea();
        cleartxt2 = new javax.swing.JButton();
        viewbtn = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1094, 1062));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 153, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Examination Form");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        searchboxtxt.setToolTipText("Enter Registration No");
        searchboxtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchboxtxtKeyReleased(evt);
            }
        });
        jPanel2.add(searchboxtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 10, 250, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/search-2-24.png"))); // NOI18N
        jLabel2.setText("Search -");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 50));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel6.setText("Sat For The Exam");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 350, -1, 30));

        idtxt.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        idtxt.setText("ID");
        jPanel1.add(idtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, 30));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel9.setText("Registration Number");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, -1, 30));

        satextxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Yes", "No" }));
        jPanel1.add(satextxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 390, 30));

        courcetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                courcetxtKeyReleased(evt);
            }
        });
        jPanel1.add(courcetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 170, 390, 30));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel13.setText("To");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 240, -1, -1));

        du2txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(du2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 230, 140, 30));

        printtxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        printtxt.setForeground(new java.awt.Color(51, 51, 51));
        printtxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/printer-24.png"))); // NOI18N
        printtxt.setText("PRINT");
        printtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printtxtActionPerformed(evt);
            }
        });
        jPanel1.add(printtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 580, 210, 40));

        updatebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        updatebtn.setForeground(new java.awt.Color(51, 51, 51));
        updatebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/available-updates-24.png"))); // NOI18N
        updatebtn.setText("UPDATE");
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        jPanel1.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 930, 210, 40));

        registertxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        registertxt.setForeground(new java.awt.Color(51, 51, 51));
        registertxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/add-user-3-24.png"))); // NOI18N
        registertxt.setText("REGISTER");
        registertxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registertxtMouseClicked(evt);
            }
        });
        registertxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registertxtActionPerformed(evt);
            }
        });
        jPanel1.add(registertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 880, 210, 40));

        deletebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        deletebtn.setForeground(new java.awt.Color(51, 51, 51));
        deletebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/delete-24.png"))); // NOI18N
        deletebtn.setText("DELETE");
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        jPanel1.add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 930, 200, 40));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel28.setText("Cource Duration");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 230, -1, 20));

        du1txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(du1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, 140, 30));

        regnotxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                regnotxtKeyReleased(evt);
            }
        });
        jPanel1.add(regnotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, 390, 30));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel8.setText("Cource");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, -1, 30));

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel43.setText("To");
        jPanel1.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 310, -1, -1));

        exd2txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(exd2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 300, 140, 30));

        jLabel44.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel44.setText("Exam Date");
        jPanel1.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, -1, 20));

        exd1txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(exd1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 300, 140, 30));

        jPanel15.setBackground(new java.awt.Color(0, 153, 51));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(0, 153, 51));
        jLabel33.setText("MODULE");
        jPanel21.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 80, 30));

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(0, 153, 51));
        jLabel34.setText("LESSON");
        jPanel21.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 100, 30));

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(0, 153, 51));
        jLabel35.setText("GRADE");
        jPanel21.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 0, 80, 30));

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 153, 51));
        jLabel36.setText("CERTIFY");
        jPanel21.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 0, 80, 30));

        jLabel37.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(0, 153, 51));
        jLabel37.setText("MARKS");
        jPanel21.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 0, 70, 30));

        jPanel15.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 590, 30));

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("EXAMINATION RECORDS");
        jPanel15.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 0, 230, 40));

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel24.setText("MODULE 01");
        jPanel7.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel25.setText("MODULE 02");
        jPanel7.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel26.setText("MODULE 03");
        jPanel7.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel27.setText("MODULE 04");
        jPanel7.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel29.setText("MODULE 09");
        jPanel7.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, -1, -1));

        jLabel30.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel30.setText("MODULE 10");
        jPanel7.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, -1, -1));

        jLabel31.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel31.setText("MODULE 12");
        jPanel7.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, -1, -1));

        jLabel32.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel32.setText("MODULE 11");
        jPanel7.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, -1, -1));

        jLabel42.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel42.setText("MODULE 08");
        jPanel7.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, -1, -1));

        jLabel45.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel45.setText("MODULE 07");
        jPanel7.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, -1));

        jLabel46.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel46.setText("MODULE 06");
        jPanel7.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, -1));

        jLabel47.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel47.setText("MODULE 05");
        jPanel7.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, -1, -1));

        jPanel15.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 110, 500));

        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel20.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel23.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel20.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel20.add(mod1ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 90, 30));
        jPanel20.add(mod2ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 90, 30));
        jPanel20.add(mod3ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 90, 30));
        jPanel20.add(mod4ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 90, 30));
        jPanel20.add(mod5ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 90, 30));
        jPanel20.add(mod6ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 90, 30));
        jPanel20.add(mod7ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 90, 30));
        jPanel20.add(mod8ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 90, 30));
        jPanel20.add(mod12ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 90, 30));
        jPanel20.add(mod11ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 90, 30));
        jPanel20.add(mod10ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 90, 30));
        jPanel20.add(mod9ctxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 90, 30));

        jPanel15.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 80, 110, 500));

        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel29.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel31.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel31.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel29.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel29.add(mod1ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 90, 30));
        jPanel29.add(mod2ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 90, 30));
        jPanel29.add(mod3ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 90, 30));
        jPanel29.add(mod4ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 90, 30));
        jPanel29.add(mod5ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 90, 30));
        jPanel29.add(mod6ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 90, 30));
        jPanel29.add(mod7ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 90, 30));
        jPanel29.add(mod8ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 90, 30));
        jPanel29.add(mod12ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 90, 30));
        jPanel29.add(mod11ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 90, 30));
        jPanel29.add(mod10ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 90, 30));
        jPanel29.add(mod9ltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 90, 30));

        jPanel15.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 110, 500));

        jPanel33.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel34.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel33.add(jPanel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel35.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel36.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel35.add(jPanel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel33.add(jPanel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));
        jPanel33.add(mod1gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 90, 30));
        jPanel33.add(mod2gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 90, 30));
        jPanel33.add(mod3gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 90, 30));
        jPanel33.add(mod4gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 90, 30));
        jPanel33.add(mod5gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 90, 30));
        jPanel33.add(mod6gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 90, 30));
        jPanel33.add(mod7gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 90, 30));
        jPanel33.add(mod8gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 90, 30));
        jPanel33.add(mod12gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 90, 30));
        jPanel33.add(mod11gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 90, 30));
        jPanel33.add(mod10gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 90, 30));
        jPanel33.add(mod9gtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 90, 30));

        jPanel15.add(jPanel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 80, 110, 500));

        jPanel37.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel38.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel37.add(jPanel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel39.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel40.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel39.add(jPanel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        jPanel37.add(jPanel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 200, 30));

        mod1mtxt.setText("0");
        jPanel37.add(mod1mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 90, 30));

        mod2mtxt.setText("0");
        jPanel37.add(mod2mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 90, 30));

        mod3mtxt.setText("0");
        jPanel37.add(mod3mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 90, 30));

        mod4mtxt.setText("0");
        jPanel37.add(mod4mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 90, 30));

        mod5mtxt.setText("0");
        jPanel37.add(mod5mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 90, 30));

        mod6mtxt.setText("0");
        mod6mtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mod6mtxtActionPerformed(evt);
            }
        });
        jPanel37.add(mod6mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 90, 30));

        mod7mtxt.setText("0");
        jPanel37.add(mod7mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 90, 30));

        mod8mtxt.setText("0");
        mod8mtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mod8mtxtActionPerformed(evt);
            }
        });
        jPanel37.add(mod8mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 90, 30));

        mod12mtxt.setText("0");
        jPanel37.add(mod12mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 90, 30));

        mod11mtxt.setText("0");
        jPanel37.add(mod11mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 90, 30));

        mod10mtxt.setText("0");
        jPanel37.add(mod10mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 90, 30));

        mod9mtxt.setText("0");
        jPanel37.add(mod9mtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 90, 30));

        jPanel15.add(jPanel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 80, 110, 500));

        totalbtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        totalbtn.setForeground(new java.awt.Color(51, 51, 51));
        totalbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/calculator-5-24.png"))); // NOI18N
        totalbtn.setText("CALCULATE TOTAL AND AVERAGE");
        totalbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalbtnActionPerformed(evt);
            }
        });
        jPanel15.add(totalbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 590, 350, 40));

        avglbl.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        avglbl.setForeground(new java.awt.Color(255, 255, 255));
        avglbl.setText("Average");
        jPanel15.add(avglbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 590, 80, 40));

        totallbl1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        totallbl1.setForeground(new java.awt.Color(255, 255, 255));
        totallbl1.setText("Total");
        jPanel15.add(totallbl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 590, 90, 40));

        jPanel1.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, 610, 640));

        jPanel3.setBackground(new java.awt.Color(0, 153, 51));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Final Grade :");
        jPanel3.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 120, 40));

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Average :");
        jPanel3.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 100, 40));

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Total Marks :");
        jPanel3.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 120, 40));

        finalgradetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                finalgradetxtKeyReleased(evt);
            }
        });
        jPanel3.add(finalgradetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 280, 40));

        avgtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                avgtxtKeyReleased(evt);
            }
        });
        jPanel3.add(avgtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 280, 40));

        totaltxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                totaltxtKeyReleased(evt);
            }
        });
        jPanel3.add(totaltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 280, 40));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 630, 430, 230));

        resipttxt.setColumns(20);
        resipttxt.setRows(5);
        jScrollPane1.setViewportView(resipttxt);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 80, 430, 490));

        cleartxt2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cleartxt2.setForeground(new java.awt.Color(51, 51, 51));
        cleartxt2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/x-mark-4-24.png"))); // NOI18N
        cleartxt2.setText("CLEAR");
        cleartxt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cleartxt2ActionPerformed(evt);
            }
        });
        jPanel1.add(cleartxt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 880, 200, 40));

        viewbtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        viewbtn.setForeground(new java.awt.Color(51, 51, 51));
        viewbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/eye-2-32.png"))); // NOI18N
        viewbtn.setText("VIEW");
        viewbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewbtnActionPerformed(evt);
            }
        });
        jPanel1.add(viewbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 580, 210, 40));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 1060));
    }// </editor-fold>//GEN-END:initComponents

    private void searchboxtxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchboxtxtKeyReleased
                                       
        if (searchboxtxt.getText().isEmpty()) {
            clear();
        }
        else{searchbox();};
        
    
        
        
    }//GEN-LAST:event_searchboxtxtKeyReleased

    private void courcetxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_courcetxtKeyReleased

    }//GEN-LAST:event_courcetxtKeyReleased

    private void printtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printtxtActionPerformed
        
        try {
            resipttxt.print();
        } catch (PrinterException ex) {
            Logger.getLogger(register_page.class.getName()).log(Level.SEVERE, null, ex);    }    
                                           
    }//GEN-LAST:event_printtxtActionPerformed

    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
        update();
    }//GEN-LAST:event_updatebtnActionPerformed

    private void registertxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registertxtMouseClicked

    }//GEN-LAST:event_registertxtMouseClicked

    private void registertxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registertxtActionPerformed
//------------------------------------------------------------------------------------------------- 
        savedata();
        try {
        String sql = "INSERT INTO examination (regno,cource,du1,du2,exd1,exd2,satexam,mod1l,mod1m,mod1g,mod1c,mod2l,mod2m,mod2g,mod2c,mod3l,mod3m,mod3g,mod3c,mod4l,mod4m ,mod4g ,mod4c ,mod5l,mod5m,mod5g,mod5c,mod6l,mod6m ,mod6g ,mod6c,mod7l ,mod7m ,mod7g ,mod7c ,mod8l ,mod8m ,mod8g ,mod8c ,mod9l ,mod9m ,mod9g ,mod9c,mod10l,mod10m,mod10g,mod10c,mod11l,mod11m,mod11g,mod11c,mod12l,mod12m,mod12g,mod12c,total,avg,grade )VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        pst = conn.prepareStatement(sql);
        pst.setString(1,regno);
        pst.setString(2,cource);
        pst.setString(3,du1);
        pst.setString(4,du2);
        pst.setString(5,exd1);
        pst.setString(6,exd2);
        pst.setString(7,satex);
        pst.setString(8,mod1l);
        pst.setString(9,mod1m);
        pst.setString(10,mod1g);
        pst.setString(11,mod1c);
        pst.setString(12,mod2l);
        pst.setString(13,mod2m);
        pst.setString(14,mod2g);
        pst.setString(15,mod2c);
        pst.setString(16,mod3l);
        pst.setString(17,mod3m);
        pst.setString(18,mod3g);
        pst.setString(19,mod3c);
        pst.setString(20,mod4l);
        pst.setString(21,mod4m);
        pst.setString(22,mod4g);
        pst.setString(23,mod4c);
        pst.setString(24,mod5l);
        pst.setString(25,mod5m);
        pst.setString(26,mod5g);
        pst.setString(27,mod5c);
        pst.setString(28,mod6l);
        pst.setString(29,mod6m);
        pst.setString(30,mod6g);
        pst.setString(31,mod6c);
        pst.setString(32,mod7l);
        pst.setString(33,mod7m);
        pst.setString(34,mod7g);
        pst.setString(35,mod7c);
        pst.setString(36,mod8l);
        pst.setString(37,mod8m);
        pst.setString(38,mod8g);
        pst.setString(39,mod8c);
        pst.setString(40,mod9l);
        pst.setString(41,mod9m);
        pst.setString(42,mod9g);
        pst.setString(43,mod9c);
        pst.setString(44,mod10l);
        pst.setString(45,mod10m);
        pst.setString(46,mod10g);
        pst.setString(47,mod10c);
        pst.setString(48,mod11l);
        pst.setString(49,mod11m);
        pst.setString(50,mod11g);
        pst.setString(51,mod11c);
        pst.setString(52,mod12l);
        pst.setString(53,mod12m);
        pst.setString(54,mod12g);
        pst.setString(55,mod12c);
         pst.setString(56,total);
          pst.setString(57,avg);
           pst.setString(58,grade);
        

        pst.execute();
        
        JOptionPane.showMessageDialog(null,"Data Insert Success!!!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"error");
        }
    }//GEN-LAST:event_registertxtActionPerformed
//------------------------------------------------------------------------------------------------- 
    public void clear(){
    regnotxt.setText("");
        courcetxt.setText("");
        du1txt.setDate(null);
        du2txt.setDate(null);
        exd1txt.setDate(null);
        exd2txt.setDate(null);
        satextxt .setSelectedIndex(-1);
        mod1ltxt.setText("");
        mod1mtxt.setText("");
        mod1gtxt.setText("");
        mod1ctxt.setText("");
        mod2ltxt.setText("");
        mod2mtxt.setText("");
        mod2gtxt.setText("");
        mod2ctxt.setText("");
        mod3ltxt .setText("");
        mod3mtxt .setText("");
        mod3gtxt .setText("");
        mod3ctxt.setText("");
       mod4ltxt.setText("");
       mod4mtxt.setText("");
       mod4gtxt.setText("");
       mod4ctxt.setText("");
       mod5ltxt .setText("");
       mod5mtxt .setText("");
       mod5gtxt .setText("");
       mod5ctxt .setText("");
       mod6ltxt .setText("");
       mod6mtxt .setText("");
       mod6gtxt .setText("");
       mod6ctxt .setText("");
       mod7ltxt .setText("");
       mod7mtxt .setText("");
       mod7gtxt .setText("");
       mod7ctxt .setText("");
       mod8ltxt .setText("");
       mod8mtxt .setText("");
       mod8gtxt .setText("");
       mod8ctxt .setText("");
       mod9ltxt .setText("");
       mod9mtxt .setText("");
       mod9gtxt .setText("");
       mod9ctxt .setText("");
       mod10ltxt .setText("");
       mod10mtxt .setText("");
       mod10gtxt .setText("");
       mod10ctxt .setText("");
       mod11ltxt .setText("");
       mod11mtxt .setText("");
       mod11gtxt .setText("");
       mod11ctxt .setText("");
       mod12ltxt .setText("");
       mod12mtxt .setText("");
       mod12gtxt .setText("");
       mod12ctxt.setText("");
       totaltxt.setText("");
       avgtxt.setText("");
       finalgradetxt.setText("");
       idtxt.setText("");
       searchboxtxt.setText("");
       resipttxt.setText("");
    }
//-------------------------------------------------------------------------------------------------  
    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
 int check = JOptionPane.showConfirmDialog(null, "Do you want to delete");

        if(check ==0){
            String id = idtxt.getText();
            try {
                String sql = "DELETE FROM examination WHERE id='"+id+"'";
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "deleted..!");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "delete error..!");
            }
        }
        clear();
        printtxt.hide();
        viewbtn.show(true);
    }//GEN-LAST:event_deletebtnActionPerformed

    private void regnotxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_regnotxtKeyReleased
        autocomplete();
        
    }//GEN-LAST:event_regnotxtKeyReleased
//------------------------------------------------------------------------------------------------- 
    private void totalbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalbtnActionPerformed
        String mark1 = mod1mtxt.getText();
        String mark2 = mod2mtxt.getText();
        String mark3 = mod3mtxt.getText();
        String mark4 = mod4mtxt.getText();
        String mark5 = mod5mtxt.getText();
        String mark6 = mod6mtxt.getText();
        String mark7 = mod7mtxt.getText();
        String mark8 = mod8mtxt.getText();
        String mark9 = mod9mtxt.getText();
        String mark10 = mod10mtxt.getText();
        String mark11 = mod11mtxt.getText();
        String mark12 = mod12mtxt.getText();
        
        int x1 = Integer.parseInt(mark1);
        int x2 = Integer.parseInt(mark2);
        int x3 = Integer.parseInt(mark3);
        int x4 = Integer.parseInt(mark4);
        int x5 = Integer.parseInt(mark5);
        int x6 = Integer.parseInt(mark6);
        int x7 = Integer.parseInt(mark7);
        int x8 = Integer.parseInt(mark8);
        int x9 = Integer.parseInt(mark9);
        int x10= Integer.parseInt(mark10);
        int x11= Integer.parseInt(mark11);
        int x12= Integer.parseInt(mark12);
        
        int sum = (x1+x2+x3+x4+x5+x6+x7+x8+x9+x10+x11+x12);
        int avg = (x1+x2+x3+x4+x5+x6+x7+x8+x9+x10+x11+x12)/12;
        
        String total = Integer.toString(sum);
        String average = Integer.toString(avg);
        totallbl1.setText(total);
        avglbl.setText(average);
        totaltxt.setText(total);
        avgtxt.setText(average);
        
        grade();
        
    }//GEN-LAST:event_totalbtnActionPerformed
//------------------------------------------------------------------------------------------------- 
public void grade(){
    
    
    String m  = avgtxt.getText();
    int avg = Integer.parseInt(m);
    if(avg>=75){
    finalgradetxt.setText("A");
    }
    else if(avg>=65){
    finalgradetxt.setText("B");
    }
    else if(avg>=45){
    finalgradetxt.setText("C");
    }
    else if(avg>=35){
    finalgradetxt.setText("S");
    }
    else{
    finalgradetxt.setText("Fail");
    }
 


}
    
    
    
    
    
    private void finalgradetxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_finalgradetxtKeyReleased

    }//GEN-LAST:event_finalgradetxtKeyReleased

    private void avgtxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_avgtxtKeyReleased

    }//GEN-LAST:event_avgtxtKeyReleased

    private void totaltxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_totaltxtKeyReleased

    }//GEN-LAST:event_totaltxtKeyReleased

    private void cleartxt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cleartxt2ActionPerformed
    clear();        
    printtxt.hide();
    viewbtn.show(true);
    }//GEN-LAST:event_cleartxt2ActionPerformed

    private void mod6mtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mod6mtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mod6mtxtActionPerformed

    private void mod8mtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mod8mtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mod8mtxtActionPerformed

    private void viewbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewbtnActionPerformed
       print();
       printtxt.show(true);
        viewbtn.hide();
    }//GEN-LAST:event_viewbtnActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel avglbl;
    private javax.swing.JTextField avgtxt;
    private javax.swing.JButton cleartxt2;
    private javax.swing.JTextField courcetxt;
    private javax.swing.JButton deletebtn;
    private com.toedter.calendar.JDateChooser du1txt;
    private com.toedter.calendar.JDateChooser du2txt;
    private com.toedter.calendar.JDateChooser exd1txt;
    private com.toedter.calendar.JDateChooser exd2txt;
    private javax.swing.JTextField finalgradetxt;
    private javax.swing.JLabel idtxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField mod10ctxt;
    private javax.swing.JTextField mod10gtxt;
    private javax.swing.JTextField mod10ltxt;
    private javax.swing.JTextField mod10mtxt;
    private javax.swing.JTextField mod11ctxt;
    private javax.swing.JTextField mod11gtxt;
    private javax.swing.JTextField mod11ltxt;
    private javax.swing.JTextField mod11mtxt;
    private javax.swing.JTextField mod12ctxt;
    private javax.swing.JTextField mod12gtxt;
    private javax.swing.JTextField mod12ltxt;
    private javax.swing.JTextField mod12mtxt;
    private javax.swing.JTextField mod1ctxt;
    private javax.swing.JTextField mod1gtxt;
    private javax.swing.JTextField mod1ltxt;
    private javax.swing.JTextField mod1mtxt;
    private javax.swing.JTextField mod2ctxt;
    private javax.swing.JTextField mod2gtxt;
    private javax.swing.JTextField mod2ltxt;
    private javax.swing.JTextField mod2mtxt;
    private javax.swing.JTextField mod3ctxt;
    private javax.swing.JTextField mod3gtxt;
    private javax.swing.JTextField mod3ltxt;
    private javax.swing.JTextField mod3mtxt;
    private javax.swing.JTextField mod4ctxt;
    private javax.swing.JTextField mod4gtxt;
    private javax.swing.JTextField mod4ltxt;
    private javax.swing.JTextField mod4mtxt;
    private javax.swing.JTextField mod5ctxt;
    private javax.swing.JTextField mod5gtxt;
    private javax.swing.JTextField mod5ltxt;
    private javax.swing.JTextField mod5mtxt;
    private javax.swing.JTextField mod6ctxt;
    private javax.swing.JTextField mod6gtxt;
    private javax.swing.JTextField mod6ltxt;
    private javax.swing.JTextField mod6mtxt;
    private javax.swing.JTextField mod7ctxt;
    private javax.swing.JTextField mod7gtxt;
    private javax.swing.JTextField mod7ltxt;
    private javax.swing.JTextField mod7mtxt;
    private javax.swing.JTextField mod8ctxt;
    private javax.swing.JTextField mod8gtxt;
    private javax.swing.JTextField mod8ltxt;
    private javax.swing.JTextField mod8mtxt;
    private javax.swing.JTextField mod9ctxt;
    private javax.swing.JTextField mod9gtxt;
    private javax.swing.JTextField mod9ltxt;
    private javax.swing.JTextField mod9mtxt;
    private javax.swing.JButton printtxt;
    private javax.swing.JButton registertxt;
    private javax.swing.JTextField regnotxt;
    private javax.swing.JTextArea resipttxt;
    private javax.swing.JComboBox satextxt;
    private javax.swing.JTextField searchboxtxt;
    private javax.swing.JButton totalbtn;
    private javax.swing.JLabel totallbl1;
    private javax.swing.JTextField totaltxt;
    private javax.swing.JButton updatebtn;
    private javax.swing.JButton viewbtn;
    // End of variables declaration//GEN-END:variables
}
