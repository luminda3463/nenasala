
package INTERFACES;
import CODES.DBconnect;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class dashbord_page extends javax.swing.JPanel {
Timer updatetimer;
int DELAY = 100;
Connection conn;
PreparedStatement pst=null;
ResultSet rs = null;
    public dashbord_page() {
        initComponents();
        conn = DBconnect.connect();
        count1();
        count2();
        count3();
        count4();
        count5();
        count6();
        clock();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        timelbl = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lable1 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lable2 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lable3 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lable4 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lable6 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        lable5 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(1094, 753));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(1094, 753));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Dashboard");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        timelbl.setFont(new java.awt.Font("Rockwell Condensed", 1, 34)); // NOI18N
        timelbl.setForeground(new java.awt.Color(255, 0, 0));
        timelbl.setText("00:00:00 AA");
        jPanel1.add(timelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 0, 210, 50));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 50));

        jPanel5.setBackground(new java.awt.Color(0, 204, 51));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setBackground(new java.awt.Color(0, 153, 0));
        jPanel10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setBackground(new java.awt.Color(204, 204, 204));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("Number Of Users");
        jPanel10.add(jLabel2);
        jPanel10.add(jLabel5);

        jPanel5.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 310, 40));

        lable1.setFont(new java.awt.Font("Tahoma", 1, 88)); // NOI18N
        lable1.setForeground(new java.awt.Color(255, 255, 255));
        lable1.setText("0");
        jPanel5.add(lable1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 140, 110));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/add-user-3-128 (1).png"))); // NOI18N
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 160, 150));

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 310, 190));

        jPanel6.setBackground(new java.awt.Color(102, 204, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel11.setBackground(new java.awt.Color(0, 204, 204));
        jPanel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setBackground(new java.awt.Color(204, 204, 204));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("Number Of Registrants");
        jPanel11.add(jLabel3);
        jPanel11.add(jLabel6);

        jPanel6.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 310, 40));

        lable2.setFont(new java.awt.Font("Tahoma", 1, 88)); // NOI18N
        lable2.setForeground(new java.awt.Color(255, 255, 255));
        lable2.setText("0");
        jPanel6.add(lable2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 140, 110));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/student-128.png"))); // NOI18N
        jPanel6.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 160, 150));

        jPanel2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 100, 310, 190));

        jPanel4.setBackground(new java.awt.Color(255, 153, 51));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel13.setBackground(new java.awt.Color(255, 102, 0));
        jPanel13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel8.setBackground(new java.awt.Color(204, 204, 204));
        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 204, 204));
        jLabel8.setText("Number Of Payments");
        jPanel13.add(jLabel8);
        jPanel13.add(jLabel9);

        jPanel4.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 310, 40));

        lable3.setFont(new java.awt.Font("Tahoma", 1, 88)); // NOI18N
        lable3.setForeground(new java.awt.Color(255, 255, 255));
        lable3.setText("0");
        jPanel4.add(lable3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 130, 110));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/us-dollar-128.png"))); // NOI18N
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 160, 150));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 100, 310, 190));

        jPanel7.setBackground(new java.awt.Color(204, 153, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel14.setBackground(new java.awt.Color(204, 102, 255));
        jPanel14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel10.setBackground(new java.awt.Color(204, 204, 204));
        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 204, 204));
        jLabel10.setText("Examinations");
        jPanel14.add(jLabel10);
        jPanel14.add(jLabel11);

        jPanel7.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 310, 40));

        lable4.setFont(new java.awt.Font("Tahoma", 1, 88)); // NOI18N
        lable4.setForeground(new java.awt.Color(255, 255, 255));
        lable4.setText("0");
        jPanel7.add(lable4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 130, 110));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/paper-128.png"))); // NOI18N
        jPanel7.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 160, 150));

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 310, 190));

        jPanel8.setBackground(new java.awt.Color(153, 153, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel15.setBackground(new java.awt.Color(51, 51, 255));
        jPanel15.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel12.setBackground(new java.awt.Color(204, 204, 204));
        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 204, 204));
        jLabel12.setText("Training");
        jPanel15.add(jLabel12);
        jPanel15.add(jLabel13);

        jPanel8.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 310, 40));

        lable6.setFont(new java.awt.Font("Tahoma", 1, 88)); // NOI18N
        lable6.setForeground(new java.awt.Color(255, 255, 255));
        lable6.setText("0");
        jPanel8.add(lable6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 140, 110));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/slideshare-128.png"))); // NOI18N
        jPanel8.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 160, 150));

        jPanel2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 320, 310, 190));

        jPanel9.setBackground(new java.awt.Color(255, 153, 153));
        jPanel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel16.setBackground(new java.awt.Color(255, 51, 51));
        jPanel16.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel14.setBackground(new java.awt.Color(204, 204, 204));
        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(204, 204, 204));
        jLabel14.setText("Completions");
        jPanel16.add(jLabel14);
        jPanel16.add(jLabel15);

        jPanel9.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 310, 40));

        lable5.setFont(new java.awt.Font("Tahoma", 1, 88)); // NOI18N
        lable5.setForeground(new java.awt.Color(255, 255, 255));
        lable5.setText("0");
        jPanel9.add(lable5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 140, 110));

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/book-2-128.png"))); // NOI18N
        jPanel9.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 160, 150));

        jPanel2.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 320, 310, 190));

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 640));
    }// </editor-fold>//GEN-END:initComponents
//------------------------------------------------------------------------------------------------- 
    public void count1(){
        try {
            String sql = "select count(id) from login";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String sum =  rs.getString("count(id)");
            lable1.setText(sum);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
//------------------------------------------------------------------------------------------------- 
    public void count2(){
        try {
            String sql = "select count(id) from register";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String sum =  rs.getString("count(id)");
            lable2.setText(sum);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
//-------------------------------------------------------------------------------------------------        
    public void count3(){
        try {
            String sql = "select count(id) from payments";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String sum =  rs.getString("count(id)");
            lable3.setText(sum);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
//-------------------------------------------------------------------------------------------------    
    public void count4(){
        try {
            String sql = "select count(id) from examination";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String sum =  rs.getString("count(id)");
            lable4.setText(sum);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
//-------------------------------------------------------------------------------------------------    
    public void count5(){
        try {
            String sql = "select count(id) from complation";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String sum =  rs.getString("count(id)");
            lable5.setText(sum);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
//-------------------------------------------------------------------------------------------------     
        public void count6(){
        try {
            String sql = "select count(id) from training";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String sum =  rs.getString("count(id)");
            lable6.setText(sum);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
//------------------------------------------------------------------------------------------------- 
    public void clock(){
            updatetimer = new Timer(DELAY, new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
          Date curreTime = new Date();
          String format = "hh:mm:ss a";
          DateFormat formatTime = new SimpleDateFormat(format);
          String formatedTime = formatTime.format(curreTime);
          
          timelbl.setText(formatedTime);
        }
    });
        updatetimer.start();
}
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lable1;
    private javax.swing.JLabel lable2;
    private javax.swing.JLabel lable3;
    private javax.swing.JLabel lable4;
    private javax.swing.JLabel lable5;
    private javax.swing.JLabel lable6;
    private javax.swing.JLabel timelbl;
    // End of variables declaration//GEN-END:variables
}
