
package INTERFACES;
import CODES.DBconnect;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class completion extends javax.swing.JPanel {
Connection conn;
PreparedStatement pst=null;
ResultSet rs = null;
    
public completion() {
    initComponents();
    conn = DBconnect.connect();
    printtxt.hide();
    }

        String regno;
        String cource;
        String du1;
        String du2;
        String fexd1;
        String fexd2;
        String fstatu;
        String handover;
        String rissu;
        String cissu;
        String cstatu;
        String place;
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        searchboxtxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        idtxt = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        rissutxt = new javax.swing.JComboBox();
        jLabel13 = new javax.swing.JLabel();
        du2txt = new com.toedter.calendar.JDateChooser();
        printtxt = new javax.swing.JButton();
        updatebtn = new javax.swing.JButton();
        registertxt = new javax.swing.JButton();
        deletebtn = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        du1txt = new com.toedter.calendar.JDateChooser();
        regnotxt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        fexd2txt = new com.toedter.calendar.JDateChooser();
        jLabel44 = new javax.swing.JLabel();
        fexd1txt = new com.toedter.calendar.JDateChooser();
        jPanel15 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        totalbtn = new javax.swing.JButton();
        avglbl = new javax.swing.JLabel();
        totallbl1 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        cstatutxt = new javax.swing.JComboBox();
        placetxt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        resipttxt = new javax.swing.JTextArea();
        cleartxt2 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        fstatutxt = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        handovertxt = new javax.swing.JComboBox();
        cissutxt = new javax.swing.JComboBox();
        courcetxt = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        viewbtn = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1094, 729));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 153, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Completion Form");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        searchboxtxt.setToolTipText("Enter Registration No");
        searchboxtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchboxtxtKeyReleased(evt);
            }
        });
        jPanel2.add(searchboxtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 10, 250, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/search-2-24.png"))); // NOI18N
        jLabel2.setText("Search -");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 50));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel6.setText("Result Sheet Issued");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, 140, 30));

        idtxt.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        idtxt.setText("ID");
        jPanel1.add(idtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, 30));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel9.setText("Registration Number");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, -1, 30));

        rissutxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Yes", "No" }));
        rissutxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rissutxtActionPerformed(evt);
            }
        });
        jPanel1.add(rissutxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 470, 420, 30));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel13.setText("To");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 240, -1, -1));

        du2txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(du2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 230, 140, 30));

        printtxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        printtxt.setForeground(new java.awt.Color(51, 51, 51));
        printtxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/printer-24.png"))); // NOI18N
        printtxt.setText("PRINT");
        printtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printtxtActionPerformed(evt);
            }
        });
        jPanel1.add(printtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 580, 210, 40));

        updatebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        updatebtn.setForeground(new java.awt.Color(51, 51, 51));
        updatebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/available-updates-24.png"))); // NOI18N
        updatebtn.setText("UPDATE");
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        jPanel1.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 630, 210, 40));

        registertxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        registertxt.setForeground(new java.awt.Color(51, 51, 51));
        registertxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/add-user-3-24.png"))); // NOI18N
        registertxt.setText("REGISTER");
        registertxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registertxtMouseClicked(evt);
            }
        });
        registertxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registertxtActionPerformed(evt);
            }
        });
        jPanel1.add(registertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 630, 200, 40));

        deletebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        deletebtn.setForeground(new java.awt.Color(51, 51, 51));
        deletebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/delete-24.png"))); // NOI18N
        deletebtn.setText("DELETE");
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        jPanel1.add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 680, 210, 40));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel28.setText("Cource Duration");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 230, -1, 20));

        du1txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(du1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, 140, 30));

        regnotxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                regnotxtKeyReleased(evt);
            }
        });
        jPanel1.add(regnotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, 420, 30));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel8.setText("Cource");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, -1, 30));

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel43.setText("To");
        jPanel1.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 310, -1, -1));

        fexd2txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(fexd2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 300, 140, 30));

        jLabel44.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel44.setText("Final Exam Date");
        jPanel1.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 300, -1, 20));

        fexd1txt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(fexd1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 300, 140, 30));

        jPanel15.setBackground(new java.awt.Color(0, 153, 51));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("After Cource Status");
        jPanel15.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 180, 40));

        totalbtn.setText("CALCULATE TOTAL AND AVERAGE");
        totalbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalbtnActionPerformed(evt);
            }
        });
        jPanel15.add(totalbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 610, 230, 40));

        avglbl.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        avglbl.setText("Average");
        jPanel15.add(avglbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 610, 80, 40));

        totallbl1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        totallbl1.setText("Total");
        jPanel15.add(totallbl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 610, 50, 40));

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Current Status Of The Trainee :");
        jPanel15.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, 50));

        cstatutxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "INHOUSE TRAINING", "SELF EMPLOYMENTS", "PRIVATE SECTOR EMPLOYMENTS", "GOV. SECTOR EMPLOYMENTS" }));
        cstatutxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cstatutxtActionPerformed(evt);
            }
        });
        jPanel15.add(cstatutxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 50, 310, 30));

        placetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                placetxtKeyReleased(evt);
            }
        });
        jPanel15.add(placetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 310, 30));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Place :");
        jPanel15.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, -1, 30));

        jPanel1.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 570, 560, 130));

        resipttxt.setColumns(20);
        resipttxt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        resipttxt.setRows(5);
        jScrollPane1.setViewportView(resipttxt);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 70, 420, 500));

        cleartxt2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cleartxt2.setForeground(new java.awt.Color(51, 51, 51));
        cleartxt2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/x-mark-4-24.png"))); // NOI18N
        cleartxt2.setText("CLEAR");
        cleartxt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cleartxt2ActionPerformed(evt);
            }
        });
        jPanel1.add(cleartxt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 680, 200, 40));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel10.setText("Final Status");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, -1, 30));

        fstatutxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "NOT COMPLETED", "NOT SAT FINAL EXAM", "NOT QULIFIED", "QULIFIED", " " }));
        fstatutxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fstatutxtActionPerformed(evt);
            }
        });
        jPanel1.add(fstatutxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 420, 30));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel11.setText("Handover The Final Project");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, -1, 30));

        handovertxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Yes", "No" }));
        handovertxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                handovertxtActionPerformed(evt);
            }
        });
        jPanel1.add(handovertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 410, 420, 30));

        cissutxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Yes", "No" }));
        cissutxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cissutxtActionPerformed(evt);
            }
        });
        jPanel1.add(cissutxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 530, 420, 30));

        courcetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                courcetxtKeyReleased(evt);
            }
        });
        jPanel1.add(courcetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 170, 420, 30));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel12.setText("Certificate Issued");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 530, -1, 30));

        viewbtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        viewbtn.setForeground(new java.awt.Color(51, 51, 51));
        viewbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/eye-2-32.png"))); // NOI18N
        viewbtn.setText("VIEW");
        viewbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewbtnActionPerformed(evt);
            }
        });
        jPanel1.add(viewbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 580, 200, 40));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 730));
    }// </editor-fold>//GEN-END:initComponents

    private void searchboxtxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchboxtxtKeyReleased
         if (searchboxtxt.getText().isEmpty()) {
            clear();
        }
        else{searchbox();};
        
    }//GEN-LAST:event_searchboxtxtKeyReleased

    private void placetxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_placetxtKeyReleased

    }//GEN-LAST:event_placetxtKeyReleased

    private void printtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printtxtActionPerformed
  
        try {
            resipttxt.print();
        } catch (PrinterException ex) {
            Logger.getLogger(register_page.class.getName()).log(Level.SEVERE, null, ex);    }  
    }//GEN-LAST:event_printtxtActionPerformed

    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
        update();
    }//GEN-LAST:event_updatebtnActionPerformed

    private void registertxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registertxtMouseClicked

    }//GEN-LAST:event_registertxtMouseClicked
//------------------------------------------------------------------------------------------------- 
    public void savedata(){
    regno = regnotxt.getText();
        cource = courcetxt.getText();
        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        du1 = dateformat.format(du1txt.getDate());
        du2 = dateformat.format(du2txt.getDate());
        fexd1 = dateformat.format(fexd1txt.getDate());
        fexd2 = dateformat.format(fexd2txt.getDate());
        fstatu=fstatutxt.getSelectedItem().toString();
        handover=handovertxt.getSelectedItem().toString();;
        rissu=rissutxt.getSelectedItem().toString();
        cissu=cissutxt.getSelectedItem().toString();
        cstatu=cstatutxt.getSelectedItem().toString();
        place=placetxt.getText();
    }
//-------------------------------------------------------------------------------------------------              
public void autocomplete(){       
        String search = regnotxt.getText();     
        try {
            String sql = "SELECT cource,du1,du2 FROM payments WHERE regno LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
            
            courcetxt.setText(rs.getString("cource"));
            du1txt.setDate(rs.getDate("du1"));
            du2txt.setDate(rs.getDate("du2"));
            
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     } }
    


//------------------------------------------------------------------------------------------------- 
public void insert(){
savedata();
        try {
        String sql = "INSERT INTO complation (regno,cource,du1,du2,fexd1,fexd2,fstatu,handover,rissu,cissu,cstatu,place)VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
        pst = conn.prepareStatement(sql);
        pst.setString(1,regno);
        pst.setString(2,cource);
        pst.setString(3,du1);
        pst.setString(4,du2);
        pst.setString(5,fexd1);
        pst.setString(6,fexd2);
        pst.setString(7,fstatu);
        pst.setString(8,handover);
        pst.setString(9,rissu);
        pst.setString(10,cissu);
        pst.setString(11,cstatu);
        pst.setString(12,place);
        pst.execute();
        
        JOptionPane.showMessageDialog(null,"Data Insert Success!!!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"error");
        }
}
//------------------------------------------------------------------------------------------------- 
public void searchbox(){       
        String search = searchboxtxt.getText();     
        try {
            String sql = "SELECT regno,cource,du1,du2,fexd1,fexd2,fstatu,handover,rissu,cissu,cstatu,place,id FROM complation WHERE regno LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
        regnotxt.setText(rs.getString("regno"));
        courcetxt .setText(rs.getString("cource"));
        du1txt.setDate(rs.getDate("du1"));
        du2txt .setDate(rs.getDate("du2"));
        fexd1txt .setDate(rs.getDate("fexd1"));
        fexd2txt .setDate(rs.getDate("fexd2"));
        fstatutxt .setSelectedItem(rs.getString("fstatu"));
        handovertxt.setSelectedItem(rs.getString("handover"));
        rissutxt.setSelectedItem(rs.getString("rissu"));
        cissutxt.setSelectedItem(rs.getString("cissu"));      
        cstatutxt.setSelectedItem(rs.getString("cstatu"));
        placetxt.setText(rs.getString("place"));                   
        idtxt.setText(rs.getString("id"));
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     }}
//-------------------------------------------------------------------------------------------------
public void clear(){
    regnotxt.setText("");
        courcetxt .setText("");
        du1txt.setDate(null);
        du2txt .setDate(null);
        fexd1txt .setDate(null);
        fexd2txt .setDate(null);
        fstatutxt .setSelectedIndex(-1);
        handovertxt.setSelectedIndex(-1);
        rissutxt.setSelectedIndex(-1);    
        cissutxt.setSelectedIndex(-1); 
        cstatutxt.setSelectedIndex(-1);     
        placetxt.setText("");      
        idtxt.setText("");        
        searchboxtxt.setText("");
        resipttxt.setText("");
}
                
//------------------------------------------------------------------------------------------------- 
    private void registertxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registertxtActionPerformed
    insert();
    }//GEN-LAST:event_registertxtActionPerformed

    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
        int check = JOptionPane.showConfirmDialog(null, "Do you want to delete");

        if(check ==0){
            String id = idtxt.getText();
            try {
                String sql = "DELETE FROM complation WHERE id='"+id+"'";
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "deleted..!");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "delete error..!");
            }
        }
        clear();
        printtxt.hide();
        viewbtn.show(true);
    }//GEN-LAST:event_deletebtnActionPerformed
//-------------------------------------------------------------------------------------------------

public void update(){
    savedata();
            try { 
        String squpdate = "UPDATE complation SET regno=?,cource=?,du1=?,du2=?,fexd1=?,fexd2=?,fstatu=?,handover=?,rissu=?,cissu=?,cstatu=?,place=? WHERE id='"+idtxt.getText()+"'";
        pst = (PreparedStatement) conn.prepareStatement(squpdate);
        pst.setString(1,regno);
        pst.setString(2,cource);
        pst.setString(3,du1);
        pst.setString(4,du2);
        pst.setString(5,fexd1);
        pst.setString(6,fexd2);
        pst.setString(7,fstatu);
        pst.setString(8,handover);
        pst.setString(9,rissu);
        pst.setString(10,cissu);
        pst.setString(11,cstatu);
        pst.setString(12,place);
        pst.execute();
        JOptionPane.showMessageDialog(null,"Update success..");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }}
//-------------------------------------------------------------------------------------------------
public void print(){
        resipttxt.append("\t\tCOMPLATION RECORDS\n"+
                "==============================================================================\n\n"+
                "Registration Number:"+"\t"+regnotxt.getText()+"\n\n"+
                "Course:"+"\t\t"+courcetxt.getText()+"\n\n"+
                "Course Duration:"+"\t"+du1txt.getDate()+du2txt.getDate()+"\n\n"+
                "Final Exam Date:"+"\t"+fexd1txt.getDate()+fexd2txt.getDate()+"\n\n"+
                "Final Status:"+"\t\t"+fstatutxt.getSelectedItem()+"\n\n"+
                "Handover The Final Project:"+"\t"+handovertxt.getSelectedItem()+"\n\n"+
                "Result Sheet Issued:"+"\t"+rissutxt.getSelectedItem()+"\n\n"+
                "Certificate Issued:"+"\t"+cissutxt.getSelectedItem()+"\n\n"+
                "Current Status:"+"\t\t"+cstatutxt.getSelectedItem()+"\n\n"+
                "Certificate Issued:"+"\t"+placetxt.getText()+"\n\n"+
                "=============================================================================="
                                         
                );
}
//-------------------------------------------------------------------------------------------------  
    private void regnotxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_regnotxtKeyReleased
        autocomplete();

    }//GEN-LAST:event_regnotxtKeyReleased

    private void totalbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalbtnActionPerformed

    }//GEN-LAST:event_totalbtnActionPerformed

    private void cleartxt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cleartxt2ActionPerformed
        clear();
        printtxt.hide();
        viewbtn.show(true);
    }//GEN-LAST:event_cleartxt2ActionPerformed

    private void rissutxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rissutxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rissutxtActionPerformed

    private void cstatutxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cstatutxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cstatutxtActionPerformed

    private void fstatutxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fstatutxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fstatutxtActionPerformed

    private void handovertxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_handovertxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_handovertxtActionPerformed

    private void cissutxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cissutxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cissutxtActionPerformed

    private void courcetxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_courcetxtKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_courcetxtKeyReleased

    private void viewbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewbtnActionPerformed
        print();
        printtxt.show(true);
        viewbtn.hide();
    }//GEN-LAST:event_viewbtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel avglbl;
    private javax.swing.JComboBox cissutxt;
    private javax.swing.JButton cleartxt2;
    private javax.swing.JTextField courcetxt;
    private javax.swing.JComboBox cstatutxt;
    private javax.swing.JButton deletebtn;
    private com.toedter.calendar.JDateChooser du1txt;
    private com.toedter.calendar.JDateChooser du2txt;
    private com.toedter.calendar.JDateChooser fexd1txt;
    private com.toedter.calendar.JDateChooser fexd2txt;
    private javax.swing.JComboBox fstatutxt;
    private javax.swing.JComboBox handovertxt;
    private javax.swing.JLabel idtxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField placetxt;
    private javax.swing.JButton printtxt;
    private javax.swing.JButton registertxt;
    private javax.swing.JTextField regnotxt;
    private javax.swing.JTextArea resipttxt;
    private javax.swing.JComboBox rissutxt;
    private javax.swing.JTextField searchboxtxt;
    private javax.swing.JButton totalbtn;
    private javax.swing.JLabel totallbl1;
    private javax.swing.JButton updatebtn;
    private javax.swing.JButton viewbtn;
    // End of variables declaration//GEN-END:variables
}
