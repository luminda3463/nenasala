package INTERFACES;
import CODES.DBconnect;
import java.awt.Image;
import java.awt.print.PrinterException;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class register_page extends javax.swing.JPanel {
    Connection conn;
    PreparedStatement pst=null;
    ResultSet rs = null;
    
//-------------------------------------------------------------------------------------------------
        public register_page(){
        initComponents();
        conn = DBconnect.connect();
        tableload();
        printtxt.hide();
        }

        String traineeno;
        String cource;
        String batch;
        String year;
        String name1;
        String name2;
        String address;
        String dob;
        String gender;
        String nic;
        String tp1;
        String tp2;
        String age;
        String nati;
        String cs;
        String dor;
        String email;
        String currents;
        String school;
        String office;

        public  ImageIcon format = null;
        String fname = null;
        int s = 0;
        byte[] pimage = null;
        
        public ImageIcon resizeImage(String imagePath, byte [] pic){
        ImageIcon myImage=null;
        if(imagePath !=null)
        {
        myImage = new ImageIcon(imagePath);
        }
        else{
        myImage = new ImageIcon(pic);
        }
        Image img=myImage.getImage();
        Image img2=img.getScaledInstance(imagelbl.getHeight(),imagelbl.getWidth(), Image.SCALE_SMOOTH);
        ImageIcon image=new ImageIcon(img2);
       return image;
        
        }
         
//-------------------------------------------------------------------------------------------------
private void savedata(){
    traineeno = tnotxt.getText();
    cource = courcetxt.getSelectedItem().toString();
    batch = batchtxt.getSelectedItem().toString();
    year = yeartxt.getSelectedItem().toString();
    name1 = name1txt.getSelectedItem().toString();
    name2 = name2txt.getText();
    address = addtxt.getText();
    
     SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
    dob =dateformat.format(dobtxt.getDate());
    gender = gendertxt.getSelectedItem().toString();
    nic = nictxt.getText();
    tp1 = hometptxt.getText();
    tp2 = mobiletptxt.getText();
    age = agetxt.getText();
    nati = natitxt.getSelectedItem().toString();
    cs = civilstxt.getSelectedItem().toString();
    
    SimpleDateFormat dateformat2 = new SimpleDateFormat("yyyy-MM-dd");
    dor = dateformat2.format(dortxt.getDate());
    email = emailtxt.getText();
    currents =currentstxt.getSelectedItem().toString();
    school = schooltxt.getText();
    office = officetxt.getText();
    }

//-------------------------------------------------------------------------------------------------              
public void tableload(){  
            try {          
           
            String sql = "SELECT id as ID,traineeno as Registration_No,cource as Course,batch as Batch,year as Year,name2 as Name,address as Address,dob as BirthDay,gender as Gender,nic as NIC,tp1 as Home_Tp,tp2 as Mobile_Tp,age as Age,nati as Nationality,cs as Civil_Status,dor as Date_Of_Registraion,email as Email,currents as Current_Status,school as School,office as Office,image as Photo FROM register";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            table1.setModel(DbUtils.resultSetToTableModel(rs));
         } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        } }
//-------------------------------------------------------------------------------------------------                            
public void clear(){
    searchtxt.setText("");
    idlbl.setText("");
    yeartxt.setSelectedIndex(-1);
    batchtxt.setSelectedIndex(-1);
    courcetxt.setSelectedIndex(-1);
    tnotxt.setText("");
    name1txt.setSelectedIndex(-1);
    name2txt.setText("");
    addtxt.setText("");
    gendertxt.setSelectedIndex(-1);
    nictxt.setText("");
    hometptxt.setText("");
    mobiletptxt.setText("");
    agetxt.setText("");
    natitxt.setSelectedIndex(-1);
    civilstxt.setSelectedIndex(-1);
    emailtxt.setText("");
    currentstxt.setSelectedIndex(-1);
    schooltxt.setText("");
    officetxt.setText("");
    imagelbl.setIcon(null);
    dobtxt.setCalendar(null);
    dortxt.setCalendar(null);
    resipttxt.setText("");
    }
//-------------------------------------------------------------------------------------------------            
public void tabledata(){       
             String id;
             DefaultTableModel tmodel = (DefaultTableModel)table1.getModel();
             int selectrowindex=table1.getSelectedRow();
             id=(tmodel.getValueAt(selectrowindex, 0).toString()); 
        try {
            String sql = "SELECT id,traineeno ,cource,batch,year,name2,address,dob,gender,nic,tp1,tp2,age,nati,cs,dor,email,currents,school,office,image FROM register WHERE id='"+id+"'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
            idlbl.setText(rs.getString("id"));
            tnotxt.setText(rs.getString("traineeno"));
            courcetxt.setSelectedItem(rs.getString("cource"));
            batchtxt.setSelectedItem(rs.getString("batch")); 
            yeartxt.setSelectedItem(rs.getString("year"));
            name2txt.setText(rs.getString("name2"));
            addtxt.setText(rs.getString("address"));
            dobtxt.setDate(rs.getDate("dob"));
            gendertxt.setSelectedItem(rs.getString("gender")); 
            nictxt.setText(rs.getString("nic"));
            hometptxt.setText(rs.getString("tp1"));
            mobiletptxt.setText(rs.getString("tp2"));
            agetxt.setText(rs.getString("age"));
            natitxt.setSelectedItem(rs.getString("nati"));
            civilstxt.setSelectedItem(rs.getString("cs")); 
            dortxt.setDate(rs.getDate("dor"));
            emailtxt.setText(rs.getString("email"));
            currentstxt.setSelectedItem(rs.getString("currents"));
            schooltxt.setText(rs.getString("school"));
            officetxt.setText(rs.getString("office"));
            
            byte[] imagedata=rs.getBytes("image");
            format=new ImageIcon(imagedata);
            Image mm=format.getImage();
            Image img=mm.getScaledInstance(imagelbl.getHeight(),imagelbl.getWidth(), Image.SCALE_SMOOTH);
            ImageIcon image=new ImageIcon(img);
            imagelbl.setIcon(image);
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     } }
//-------------------------------------------------------------------------------------------------
    public void search(){
        String search = searchtxt.getText();
        try {
            String sql = "SELECT * FROM register WHERE name2 LIKE'%"+search+"%'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            table1.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }}
//-------------------------------------------------------------------------------------------------
public void print(){
        resipttxt.append("\t\t STUDENT RECORDS \n"+
                "=================================================================\n\n"+
                "YEAR:\t\t"+yeartxt.getSelectedItem()+"\n"+
                "ID:\t\t"+idlbl.getText()+"\n"+
                "REG NO:\t\t"+tnotxt.getText()+"\n"+
                "COURSE:\t\t"+courcetxt.getSelectedItem()+"\n"+
                "BATCH:\t\t"+batchtxt.getSelectedItem()+"\n"+
                "NAME:\t\t"+name1txt.getSelectedItem()+name2txt.getText()+"\n"+
                "ADDRESS:\t\t"+addtxt.getText()+"\n"+
                "DOB:\t\t"+dobtxt.getDate()+"\n"+
                "GENDER:\t\t"+gendertxt.getSelectedItem()+"\n"+
                "NIC:\t\t"+nictxt.getText()+"\n"+
                "HOME TP:\t\t"+mobiletptxt.getText()+"\n"+
                "MOBILE TP:\t\t"+hometptxt.getText()+"\n"+
                "AGE:\t\t"+agetxt.getText()+"\n"+
                "NATIONALITY:\t"+natitxt.getSelectedItem()+"\n"+
                "CIVIL STATUS:\t"+civilstxt.getSelectedItem()+"\n"+
                "DATE OF REG:\t"+dortxt.getDate()+"\n"+
                "E-MAIL:\t\t"+emailtxt.getText()+"\n"+
                "CURRENT STATUS:\t"+currentstxt.getSelectedItem()+"\n"+
                "SCHOOL:\t\t"+schooltxt.getText()+"\n"+
                "WORK OFFICE:\t"+officetxt.getText()+"\n\n"+
                "==================================================================="       
        );}
//-------------------------------------------------------------------------------------------------  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        searchtxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        courcetxt = new javax.swing.JComboBox();
        yeartxt = new javax.swing.JComboBox();
        tnotxt = new javax.swing.JTextField();
        batchtxt = new javax.swing.JComboBox();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        mobiletptxt = new javax.swing.JTextField();
        natitxt = new javax.swing.JComboBox();
        name1txt = new javax.swing.JComboBox();
        gendertxt = new javax.swing.JComboBox();
        civilstxt = new javax.swing.JComboBox();
        currentstxt = new javax.swing.JComboBox();
        hometptxt = new javax.swing.JTextField();
        nictxt = new javax.swing.JTextField();
        addtxt = new javax.swing.JTextField();
        agetxt = new javax.swing.JTextField();
        name2txt = new javax.swing.JTextField();
        schooltxt = new javax.swing.JTextField();
        officetxt = new javax.swing.JTextField();
        emailtxt = new javax.swing.JTextField();
        dobtxt = new com.toedter.calendar.JDateChooser();
        dortxt = new com.toedter.calendar.JDateChooser();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        resipttxt = new javax.swing.JTextArea();
        printtxt = new javax.swing.JButton();
        cleartxt = new javax.swing.JButton();
        registertxt = new javax.swing.JButton();
        deletetxt = new javax.swing.JButton();
        viewbtn = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        idlbl = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        imagelbl = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 153, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Registration Form");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        searchtxt.setToolTipText("Enter Name");
        searchtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchtxtKeyReleased(evt);
            }
        });
        jPanel2.add(searchtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 10, 250, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/search-2-24.png"))); // NOI18N
        jLabel2.setText("Search -");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 50));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel6.setText("Year");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 40, 30));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel7.setText("Cource");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, 30));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel9.setText("Registration Number");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 290, -1, 30));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel8.setText("Batch");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 240, -1, 30));

        courcetxt.setForeground(new java.awt.Color(0, 102, 0));
        courcetxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Certificate In Basic Information Technology", "Certificate In Basic Graphic Design", "Certificate In Basic Computer Hardware Technology", "Certificate In Information Technology", "Diploma In Information Technology", "Certificate In Graphic Design" }));
        jPanel1.add(courcetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 320, 30));

        yeartxt.setForeground(new java.awt.Color(0, 102, 0));
        yeartxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "2015", "2016", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030" }));
        jPanel1.add(yeartxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 320, 30));
        jPanel1.add(tnotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 290, 290, 30));

        batchtxt.setForeground(new java.awt.Color(0, 102, 0));
        batchtxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "I", "II", "III" }));
        jPanel1.add(batchtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 240, 290, 30));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel15.setText("Gender");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 60, -1));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel16.setText("NIC Number");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 570, 90, -1));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel17.setText("Home TP Number");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 620, 130, -1));

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel18.setText("Current Status");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 960, -1, -1));

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel19.setText("E-mail Address");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 920, -1, -1));

        jLabel20.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel20.setText("School Name(If Available)");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1010, -1, -1));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel21.setText("Work Office Name(If Available)");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1060, -1, -1));

        jLabel22.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel22.setText("Age");
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 720, 30, -1));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel13.setText("Date Of Birth");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 100, -1));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel14.setText("Name");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 40, -1));

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel23.setText("Civil Status");
        jPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 820, -1, -1));

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel24.setText("Nationality");
        jPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 770, -1, -1));

        jLabel25.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel25.setText("Mobile TP Number");
        jPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 670, 130, -1));

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel26.setText("Date Of Registration");
        jPanel1.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 870, -1, -1));
        jPanel1.add(mobiletptxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 670, 490, 30));

        natitxt.setForeground(new java.awt.Color(0, 102, 0));
        natitxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Sinhala", "Tamil", "Muslim", "Other" }));
        natitxt.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.add(natitxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 770, 540, 30));

        name1txt.setForeground(new java.awt.Color(0, 102, 0));
        name1txt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Rev.", "Mr.", "Mrs.", "Miss." }));
        name1txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name1txtActionPerformed(evt);
            }
        });
        jPanel1.add(name1txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 370, 70, 30));

        gendertxt.setForeground(new java.awt.Color(0, 102, 0));
        gendertxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Male", "Female" }));
        gendertxt.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.add(gendertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 520, 520, 30));

        civilstxt.setForeground(new java.awt.Color(0, 102, 0));
        civilstxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Unmarried", "Married", "Other" }));
        civilstxt.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.add(civilstxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 820, 540, 30));

        currentstxt.setForeground(new java.awt.Color(0, 102, 0));
        currentstxt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "In School  Education", "After School Education", "Looking For Jobs", "Employed" }));
        currentstxt.setPreferredSize(new java.awt.Dimension(6, 20));
        jPanel1.add(currentstxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 960, 520, 30));
        jPanel1.add(hometptxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 620, 490, 30));

        nictxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nictxtActionPerformed(evt);
            }
        });
        jPanel1.add(nictxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 570, 520, 30));
        jPanel1.add(addtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, 520, 30));
        jPanel1.add(agetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 720, 540, 30));

        name2txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name2txtActionPerformed(evt);
            }
        });
        jPanel1.add(name2txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 370, 500, 30));
        jPanel1.add(schooltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 1010, 400, 30));

        officetxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                officetxtActionPerformed(evt);
            }
        });
        jPanel1.add(officetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 1060, 400, 30));
        jPanel1.add(emailtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 920, 520, 30));

        dobtxt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(dobtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 520, 30));
        dobtxt.getAccessibleContext().setAccessibleName("");
        dobtxt.getAccessibleContext().setAccessibleDescription("");

        dortxt.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(dortxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 870, 480, 30));

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9", "Title 10", "Title 11", "Title 12", "Title 13", "Title 14", "Title 15", "Title 16", "Title 17", "Title 18", "Title 19", "Title 20"
            }
        ));
        table1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table1);

        jPanel5.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 5390, 110));

        jScrollPane2.setViewportView(jPanel5);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 1070, 140));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/photo-24.png"))); // NOI18N
        jButton1.setText("Brows Photo");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 350, -1, 30));

        resipttxt.setColumns(20);
        resipttxt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        resipttxt.setRows(5);
        resipttxt.setBorder(null);
        jScrollPane3.setViewportView(resipttxt);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 400, 400, 460));

        printtxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        printtxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/printer-24.png"))); // NOI18N
        printtxt.setText("PRINT");
        printtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printtxtActionPerformed(evt);
            }
        });
        jPanel1.add(printtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 870, 200, 40));

        cleartxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cleartxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/x-mark-4-24.png"))); // NOI18N
        cleartxt.setText("CLEAR");
        cleartxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cleartxtActionPerformed(evt);
            }
        });
        jPanel1.add(cleartxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 1000, 200, 40));

        registertxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        registertxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/add-user-3-24.png"))); // NOI18N
        registertxt.setText("REGISTER");
        registertxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registertxtMouseClicked(evt);
            }
        });
        registertxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registertxtActionPerformed(evt);
            }
        });
        jPanel1.add(registertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 950, 200, 40));

        deletetxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        deletetxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/delete-24.png"))); // NOI18N
        deletetxt.setText("DELETE");
        deletetxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletetxtActionPerformed(evt);
            }
        });
        jPanel1.add(deletetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 1000, 200, 40));

        viewbtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        viewbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/eye-2-32.png"))); // NOI18N
        viewbtn.setText("VIEW");
        viewbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewbtnMouseClicked(evt);
            }
        });
        viewbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewbtnActionPerformed(evt);
            }
        });
        jPanel1.add(viewbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 870, 200, 40));

        jLabel27.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel27.setText("Address");
        jPanel1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, 60, -1));

        idlbl.setText("ID");
        jPanel1.add(idlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 20, 20));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/available-updates-24.png"))); // NOI18N
        jButton2.setText("UPDATE");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 950, 200, 40));

        imagelbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/businessman-128.png"))); // NOI18N
        jPanel1.add(imagelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 220, 140, 170));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 1120));
    }// </editor-fold>//GEN-END:initComponents

    private void name1txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name1txtActionPerformed

    }//GEN-LAST:event_name1txtActionPerformed

    private void nictxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nictxtActionPerformed

    }//GEN-LAST:event_nictxtActionPerformed

    private void name2txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name2txtActionPerformed

    }//GEN-LAST:event_name2txtActionPerformed

    private void officetxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_officetxtActionPerformed

    }//GEN-LAST:event_officetxtActionPerformed

    private void printtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printtxtActionPerformed

        try {
            resipttxt.print();
        } catch (PrinterException ex) {
            Logger.getLogger(register_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_printtxtActionPerformed

    private void cleartxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cleartxtActionPerformed
        clear();
    }//GEN-LAST:event_cleartxtActionPerformed

    private void registertxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registertxtActionPerformed

             savedata(); 
        try {
        String sql = "INSERT INTO register (traineeno,cource,batch,year,name1,name2,address,dob,gender,nic,tp1,tp2,age,nati,cs,dor,email,currents,school,office,image)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        pst = conn.prepareStatement(sql);
        pst.setString(1,traineeno);
        pst.setString(2,cource);
        pst.setString(3,batch);
        pst.setString(4,year);
        pst.setString(5,name1);
        pst.setString(6,name2);
        pst.setString(7,address);
        pst.setString(8,dob);
        pst.setString(9,gender);
        pst.setString(10,nic);
        pst.setString(11,tp1);
        pst.setString(12,tp2);
        pst.setString(13,age);
        pst.setString(14,nati);
        pst.setString(15,cs);
        pst.setString(16,dor);
        pst.setString(17,email);
        pst.setString(18,currents);
        pst.setString(19,school);
        pst.setString(20,office);
        pst.setBytes(21, pimage);
        pst.execute();
        JOptionPane.showMessageDialog(null,"Data Insert Success!!!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Registration Number Is Already Exist !");
        }
        tableload();   
    }//GEN-LAST:event_registertxtActionPerformed

    private void deletetxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletetxtActionPerformed
int check = JOptionPane.showConfirmDialog(null, "Do you want to delete");

        if(check ==0){
            String id = idlbl.getText();
            try {
                String sql = "DELETE FROM register WHERE id='"+id+"'";
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "deleted..!");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "delete error..!");
            }
        }
        tableload();
        clear();       
    }//GEN-LAST:event_deletetxtActionPerformed

    private void viewbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewbtnActionPerformed
    print();        
    }//GEN-LAST:event_viewbtnActionPerformed

    private void registertxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registertxtMouseClicked
    
    }//GEN-LAST:event_registertxtMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        JFileChooser fchoser = new JFileChooser();
        fchoser.showOpenDialog(null);
        File f = fchoser.getSelectedFile();
        fname= f.getAbsolutePath();
        ImageIcon micon = new ImageIcon(fname);
        try {
            File image =new File(fname);
            FileInputStream fis = new FileInputStream(image);
            ByteArrayOutputStream boas = new  ByteArrayOutputStream();
            byte[] buf=new byte[1024];
            for(int readnum;(readnum = fis.read(buf))!=-1;)
            {
            boas.write(buf,0,readnum);
            }
            pimage=boas.toByteArray();
            imagelbl.setIcon(resizeImage(fname,buf));
                    
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void table1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table1MouseClicked
        tabledata();
    }//GEN-LAST:event_table1MouseClicked

    private void searchtxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchtxtKeyReleased

        search();
    }//GEN-LAST:event_searchtxtKeyReleased

    public void update(){
        savedata();    
        try {
        String squpdate = "UPDATE register SET  traineeno=?,cource=?,batch=?,year=?,name1=?,name2=?,address=?,dob=?,gender=?,nic=?,tp1=?,tp2=?,age=?,nati=?,cs=?,dor=?,email=?,currents=?,school=?,office=? WHERE id='"+idlbl.getText()+"'";
        pst = (PreparedStatement) conn.prepareStatement(squpdate);
        pst.setString(1,traineeno);
        pst.setString (2,cource);
        pst.setString (3,batch);
        pst.setString (4,year);
        pst.setString (5,name1);
        pst.setString (6,name2);
        pst.setString (7,address);
        pst.setString (8,dob);
        pst.setString (9,gender);
        pst.setString (10,nic);
        pst.setString (11,tp1);  
        pst.setString (12,tp2);
        pst.setString (13,age);
        pst.setString (14,nati);
        pst.setString (15,cs);
        pst.setString (16,dor);
        pst.setString (17,email);
        pst.setString (18,currents);
        pst.setString (19,school);
        pst.setString (20,office);       
        pst.execute();
        JOptionPane.showMessageDialog(null,"Update success..");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }
//-------------Image update---------------------------------------------------------------------------  
        String value1 = idlbl.getText();
        try {
        File file = new File(fname);
        FileInputStream fis = new FileInputStream(file);
        byte[] image = new byte[(int)file.length()];
        fis.read(image);
        
        String sql = "update items set image = ? where id='"+value1+"'";
        pst=conn.prepareStatement(sql);
        pst.setBytes(1, image);
        pst.executeUpdate();
        pst.close();;
        } catch (Exception e) {
        }
        tableload();
}
//-------------------------------------------------------------------------------------------------
    
    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        
        update();
        tableload();
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

    }//GEN-LAST:event_jButton2ActionPerformed

    private void viewbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewbtnMouseClicked
        printtxt.show(true);
        viewbtn.hide();
    }//GEN-LAST:event_viewbtnMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField addtxt;
    private javax.swing.JTextField agetxt;
    private javax.swing.JComboBox batchtxt;
    private javax.swing.JComboBox civilstxt;
    private javax.swing.JButton cleartxt;
    private javax.swing.JComboBox courcetxt;
    private javax.swing.JComboBox currentstxt;
    private javax.swing.JButton deletetxt;
    private com.toedter.calendar.JDateChooser dobtxt;
    private com.toedter.calendar.JDateChooser dortxt;
    private javax.swing.JTextField emailtxt;
    private javax.swing.JComboBox gendertxt;
    private javax.swing.JTextField hometptxt;
    private javax.swing.JLabel idlbl;
    private javax.swing.JLabel imagelbl;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField mobiletptxt;
    private javax.swing.JComboBox name1txt;
    private javax.swing.JTextField name2txt;
    private javax.swing.JComboBox natitxt;
    private javax.swing.JTextField nictxt;
    private javax.swing.JTextField officetxt;
    private javax.swing.JButton printtxt;
    private javax.swing.JButton registertxt;
    private javax.swing.JTextArea resipttxt;
    private javax.swing.JTextField schooltxt;
    private javax.swing.JTextField searchtxt;
    private javax.swing.JTable table1;
    private javax.swing.JTextField tnotxt;
    private javax.swing.JButton viewbtn;
    private javax.swing.JComboBox yeartxt;
    // End of variables declaration//GEN-END:variables

    }
