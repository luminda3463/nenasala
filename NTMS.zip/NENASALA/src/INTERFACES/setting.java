package INTERFACES;
import CODES.DBconnect;
import static INTERFACES.login.TWO_SECOND;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class setting extends javax.swing.JFrame {
Connection conn;
PreparedStatement pst=null;
ResultSet rs = null;
    public setting() {
        initComponents();
        conn = DBconnect.connect();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        passtxt = new javax.swing.JTextField();
        usertxt = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        idlbl = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        repwordtxt = new javax.swing.JTextField();
        unametxt = new javax.swing.JTextField();
        mailtxt = new javax.swing.JTextField();
        pwordtxt = new javax.swing.JTextField();
        updatebtn = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(397, 430));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(391, 584));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(0, 153, 51));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Enter You'r");
        jPanel6.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 130, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("password");
        jPanel6.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));
        jPanel6.add(passtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 360, 30));

        usertxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                usertxtKeyReleased(evt);
            }
        });
        jPanel6.add(usertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 360, 30));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Click Hear To Update");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 360, -1));
        jPanel6.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 360, 2));

        jPanel8.setBackground(new java.awt.Color(255, 0, 0));
        jPanel6.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 380, 2));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("user name");
        jPanel6.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Current User Name And Password");
        jPanel6.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 380, 40));
        jPanel6.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 360, 2));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 400, 360));

        idlbl.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        idlbl.setText("ID");
        jPanel1.add(idlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 20, 20));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("User Name");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("E-mail");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Password");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Re-Enter Password");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, -1, -1));
        jPanel1.add(repwordtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 350, 30));

        unametxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                unametxtKeyReleased(evt);
            }
        });
        jPanel1.add(unametxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 350, 30));
        jPanel1.add(mailtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 350, 30));
        jPanel1.add(pwordtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 350, 30));

        updatebtn.setBackground(new java.awt.Color(255, 255, 255));
        updatebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updatebtnMouseClicked(evt);
            }
        });
        updatebtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));
        jLabel1.setText("Update");
        updatebtn.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 80, 30));

        jPanel1.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 350, 30));
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 350, 1));
        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 350, 1));
        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 350, 1));
        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 350, 1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICONS/close-window-32.png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, 50, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 430));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    //-------------------------------------------------------------------------------------------------              
public void autocomplete(){       
        String search = unametxt.getText();     
        try {
            String sql = "SELECT id,uname,mail,pword,repword FROM login WHERE uname LIKE'%"+search+"%'";
            pst = (com.mysql.jdbc.PreparedStatement)conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
            idlbl.setText(rs.getString("id"));
            unametxt.setText(rs.getString("uname"));
            mailtxt.setText(rs.getString("mail"));
            pwordtxt.setText(rs.getString("pword"));
            repwordtxt.setText(rs.getString("repword"));
            
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
                     } 
}
//------------------------------------------------------------------------------------------------- 
    private void updatebtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updatebtnMouseClicked
        update();
    }//GEN-LAST:event_updatebtnMouseClicked

    private void unametxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_unametxtKeyReleased
        
       
    }//GEN-LAST:event_unametxtKeyReleased
//------------------------------------------------------------------------------------------------- 
    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        this.dispose();
        home m = new home();
        m.setVisible(true);
    }//GEN-LAST:event_jLabel2MouseClicked
//------------------------------------------------------------------------------------------------- 
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        log();        
        
    }//GEN-LAST:event_jButton1ActionPerformed
//------------------------------------------------------------------------------------------------- 
    private void usertxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_usertxtKeyReleased
        autocomplete();
         if (usertxt.getText().isEmpty()) {
           unametxt.setText("");
            idlbl.setText("");
            mailtxt.setText("");
            pwordtxt.setText("");
            repwordtxt.setText("");
        }
    }//GEN-LAST:event_usertxtKeyReleased

//------------------------------------------------------------------------------------------------- 
public void log(){
       
        String password;
        String name;
        String u=usertxt.getText();
        String p=passtxt.getText();
        
        
        try {
        String sql="select pword,uname from login where uname='"+u+"'";
        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        if(rs.next()){
        password = (rs.getString("pword"));
        name = (rs.getString("uname"));
            if (password.equals(p)&& name.equals(u))  { 

        JOptionPane.showMessageDialog(rootPane, "Correct!");
        jPanel6.hide();
        }
           
        }
        else{
        JOptionPane.showMessageDialog(rootPane, "Please Enter Correct Details!");
        }
        } catch (Exception e) {
            
        }
}


//------------------------------------------------------------------------------------------------- 
public void update(){
    if (unametxt.getText().isEmpty()||mailtxt.getText().isEmpty()||pwordtxt.getText().isEmpty()||repwordtxt.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null,"Please Enter Valid Details...!");}
        
    
    else{
        
        
        
        String uname=unametxt.getText();
        String mail=mailtxt.getText();
        String pword=pwordtxt.getText();
        String repword=repwordtxt.getText();
        
        
        
        try {
        String squpdate = "UPDATE login SET  uname=?,mail=?,pword=?,repword=? WHERE id='"+idlbl.getText()+"'";
        pst = (PreparedStatement) conn.prepareStatement(squpdate);
        pst.setString(1,uname);
        pst.setString (2,mail);
        pst.setString (3,pword);
        pst.setString (4,repword);
        pst.execute();
        JOptionPane.showMessageDialog(null,"Update success..");
                login log=new login();
                log.setVisible(true);
                this.dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }
        
            }
        
        
    

}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(setting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(setting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(setting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(setting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new setting().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel idlbl;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTextField mailtxt;
    private javax.swing.JTextField passtxt;
    private javax.swing.JTextField pwordtxt;
    private javax.swing.JTextField repwordtxt;
    private javax.swing.JTextField unametxt;
    private javax.swing.JPanel updatebtn;
    private javax.swing.JTextField usertxt;
    // End of variables declaration//GEN-END:variables
}
